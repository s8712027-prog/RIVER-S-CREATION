# Next Window Handoff

Current branch: `GCF-UMA v0.1a`.

Locked status: `BRANCH_MULTIPLEXING_CONTRACT_NEGOTIATION_PASS`.

Next candidate: `GCF-UMA v0.1b — Transactional Session, Replay Protection, and Failure Recovery`.

Priorities:
1. branch session identity and monotonic sequence numbers;
2. duplicate/replayed message rejection;
3. idempotent host binding;
4. pending/committed/aborted transaction lifecycle;
5. partial branch outage and timeout handling;
6. stale certificate and stale evidence expiry;
7. rollback/audit receipt interface;
8. mocked transport plugin without adding branch logic.
