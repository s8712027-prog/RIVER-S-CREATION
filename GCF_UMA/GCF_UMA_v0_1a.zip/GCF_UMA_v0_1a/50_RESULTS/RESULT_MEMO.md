# GCF-UMA v0.1a Result Memo

Verdict: `BRANCH_MULTIPLEXING_CONTRACT_NEGOTIATION_PASS`

## Formal results

- v0.1a multiplex gates: 14/14 PASS
- total unit/regression tests: 30/30 PASS
- original v0.1 adapter tests retained: 10/10 PASS
- new v0.1a tests: 20/20 PASS

## Validated in the locked mock harness

- exact contract-version negotiation;
- unknown/incompatible branch rejection;
- branch-role isolation;
- deterministic routing and priority order;
- OBS policy-advisory separation from AI-8 final actions;
- ambiguous action conflict blocking;
- declarative evidence and certificate preconditions;
- provenance namespace preservation;
- semantic-loss audit sidecars;
- host authority/capability/ramp preservation;
- energy/6G host-binding isolation;
- invalid-message failure isolation;
- no hidden action generation from BH annotations.

## Important correction made before archive

An early internal draft treated OBS bounded-rescue output and AI-8 output as peer action candidates and proposed selecting the larger magnitude. That design was rejected because it would recreate branch responsibility overlap and allow the Adapter to make an undeclared policy choice.

The formal v0.1a design instead locks:

- OBS bounded-rescue output → `policy_advisory`;
- AI-8 output → final `action_candidate`;
- differing intents or differing magnitudes → explicit conflict, no host binding.

## Boundary

This is a synthetic integration-contract result. It does not validate real energy, fusion, or 6G host APIs; it does not generate or independently verify BCRC-PGRC certificates; and it is not a Safety Governor or deployment authorization layer.
