# GCF-UMA v0.1a — Branch Multiplexing and Contract Negotiation

Status: `BRANCH_MULTIPLEXING_CONTRACT_NEGOTIATION_PASS`

GCF-UMA v0.1a extends the unchanged v0.1 domain/host adapter kernel with a reusable branch-composition layer for:

- OBS-CoreV2 evidence, observation requests, and policy advisories;
- AI-8 final action intents;
- BH topology/margin annotations;
- BCRC-PGRC explicit certificate status.

The multiplexer validates branch identity, contract ID, exact compatible version, message role, payload schema, provenance namespace, explicit evidence/certificate preconditions, and host capability/authority constraints.

It does not execute branch inference, calculate certificates, turn BH priors into actions, or replace a Safety Governor.
