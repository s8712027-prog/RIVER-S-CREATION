# GCF-UMA Branch Charter — v0.1a

## Core responsibility

GCF-UMA is reusable integration middleware between GCF branch contracts, generic domain contracts, domain profiles, and host profiles.

## v0.1a branch-boundary rule

- OBS-CoreV2 outputs evidence, observation requests, and bounded-policy advisories.
- AI-8 is the only registered final action-intent provider in this profile.
- BH outputs topology/margin annotations only.
- BCRC-PGRC outputs explicit certificate status only.
- GCF-UMA validates, routes, preserves provenance, detects ambiguity, and binds eligible intents to host operations.

## Non-responsibilities

- no structural-risk inference;
- no state forecast;
- no AI-8 routing calculation;
- no BH margin calculation;
- no BCRC-PGRC certificate generation;
- no Safety Governor approval;
- no domain optimization.

## Conflict rule

The Adapter never guesses between semantically different intents. Different intents for the same target, or nominally identical intents with different magnitudes, are marked as conflicts and are not host-bound.
