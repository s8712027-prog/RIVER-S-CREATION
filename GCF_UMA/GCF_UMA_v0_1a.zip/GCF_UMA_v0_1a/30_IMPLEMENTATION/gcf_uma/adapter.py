from __future__ import annotations
from copy import deepcopy
from dataclasses import asdict
from pathlib import Path
from typing import Any, Dict
import yaml

from .models import BoundOutput, GenericIntent

class AdapterError(ValueError):
    pass

class UniversalAdapter:
    def __init__(self, profile: Dict[str, Any]):
        self.profile = deepcopy(profile)
        for key in ("profile_id", "domain_id", "input_mapping", "capabilities", "authority", "host_binding"):
            if key not in self.profile:
                raise AdapterError(f"profile missing required field: {key}")
        self._previous_magnitude: Dict[str, float] = {}

    @classmethod
    def from_yaml(cls, path: str | Path) -> "UniversalAdapter":
        with open(path, "r", encoding="utf-8") as f:
            return cls(yaml.safe_load(f))

    @staticmethod
    def _set_nested(root: Dict[str, Any], path: str, value: Any) -> None:
        parts = path.split(".")
        cursor = root
        for part in parts[:-1]:
            cursor = cursor.setdefault(part, {})
        cursor[parts[-1]] = value

    def to_generic(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        required = ("timestamp", "entities", "provenance")
        missing = [k for k in required if k not in payload]
        if missing:
            raise AdapterError(f"input missing required fields: {missing}")
        out: Dict[str, Any] = {
            "domain_id": self.profile["domain_id"],
            "timestamp": float(payload["timestamp"]),
            "entities": deepcopy(payload["entities"]),
            "resources": {},
            "observations": {},
            "dependencies": deepcopy(payload.get("dependencies", [])),
            "priorities": deepcopy(payload.get("priorities", {})),
            "control_state": deepcopy(payload.get("control_state", {})),
            "provenance": deepcopy(payload["provenance"]),
        }
        transformations = []
        for source_field, spec in self.profile["input_mapping"].items():
            if source_field not in payload:
                raise AdapterError(f"profile-declared field missing: {source_field}")
            raw = payload[source_field]
            if not isinstance(raw, (int, float)):
                raise AdapterError(f"field {source_field} must be numeric")
            value = float(raw) * float(spec.get("scale", 1.0))
            self._set_nested(out, spec["generic"], value)
            transformations.append({
                "source_field": source_field,
                "generic_field": spec["generic"],
                "scale": float(spec.get("scale", 1.0)),
                "unit_in": spec.get("unit_in"),
                "unit_out": spec.get("unit_out"),
            })
        out["provenance"]["adapter_profile_id"] = self.profile["profile_id"]
        out["provenance"]["transformations"] = transformations
        return out

    def bind_intent(self, intent: GenericIntent) -> BoundOutput:
        caps = self.profile["capabilities"]
        if intent.intent not in caps:
            raise AdapterError(f"unsupported capability: {intent.intent}")
        cap = caps[intent.intent]
        if not bool(cap.get("enabled", False)):
            raise AdapterError(f"disabled capability: {intent.intent}")
        if intent.intent not in self.profile["host_binding"]:
            raise AdapterError(f"missing host binding: {intent.intent}")
        requested = max(0.0, min(1.0, float(intent.magnitude)))
        bounded = min(requested, float(cap["max_magnitude"]))
        prev = self._previous_magnitude.get(intent.intent, 0.0)
        ramp = float(cap["ramp_limit"])
        bounded = min(max(bounded, prev - ramp), prev + ramp)
        self._previous_magnitude[intent.intent] = bounded
        mode = self.profile["authority"].get(intent.intent, self.profile["authority"].get("default", "PROHIBITED"))
        executable = mode == "AUTO_BOUNDED"
        approval_required = mode == "APPROVAL_REQUIRED"
        if mode in ("ADVISORY", "SIMULATION", "PROHIBITED"):
            executable = False
        prov = deepcopy(intent.provenance)
        prov["adapter_profile_id"] = self.profile["profile_id"]
        prov["requested_magnitude"] = requested
        prov["bounded_magnitude"] = bounded
        return BoundOutput(
            host_operation=self.profile["host_binding"][intent.intent],
            target=intent.target,
            magnitude=bounded,
            authority_mode=mode,
            executable=executable,
            approval_required=approval_required,
            provenance=prov,
        )
