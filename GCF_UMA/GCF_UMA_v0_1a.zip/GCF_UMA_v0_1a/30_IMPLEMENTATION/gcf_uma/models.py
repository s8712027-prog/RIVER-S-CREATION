from __future__ import annotations
from dataclasses import asdict, dataclass, field
from typing import Any, Dict, List

@dataclass(frozen=True)
class GenericIntent:
    intent: str
    target: str
    magnitude: float
    reason: str = ""
    provenance: Dict[str, Any] = field(default_factory=dict)

@dataclass(frozen=True)
class BoundOutput:
    host_operation: str
    target: str
    magnitude: float
    authority_mode: str
    executable: bool
    approval_required: bool
    provenance: Dict[str, Any]

@dataclass(frozen=True)
class BranchEnvelope:
    message_id: str
    branch_id: str
    contract_id: str
    contract_version: str
    message_type: str
    payload: Dict[str, Any]
    priority: int = 50
    provenance: Dict[str, Any] = field(default_factory=dict)

@dataclass(frozen=True)
class NegotiationResult:
    branch_id: str
    state: str
    selected_version: str | None = None
    reason: str = ""

@dataclass
class MultiplexResult:
    status: str
    accepted_message_ids: List[str] = field(default_factory=list)
    rejected_messages: List[Dict[str, Any]] = field(default_factory=list)
    evidence: List[Dict[str, Any]] = field(default_factory=list)
    observation_requests: List[Dict[str, Any]] = field(default_factory=list)
    policy_advisories: List[Dict[str, Any]] = field(default_factory=list)
    annotations: List[Dict[str, Any]] = field(default_factory=list)
    certificates: List[Dict[str, Any]] = field(default_factory=list)
    action_candidates: List[Dict[str, Any]] = field(default_factory=list)
    selected_actions: List[Dict[str, Any]] = field(default_factory=list)
    conflicts: List[Dict[str, Any]] = field(default_factory=list)
    semantic_loss_ledger: List[Dict[str, Any]] = field(default_factory=list)
    audit: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)
