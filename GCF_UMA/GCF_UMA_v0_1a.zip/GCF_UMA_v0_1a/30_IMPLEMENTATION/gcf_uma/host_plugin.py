from __future__ import annotations
from dataclasses import asdict
from typing import Any, Dict, List

from .adapter import UniversalAdapter
from .models import MultiplexResult
from .multiplexer import BranchMultiplexer

class AdapterHostPlugin:
    def __init__(self, adapter: UniversalAdapter):
        self.adapter = adapter

    def bind(self, result: MultiplexResult) -> Dict[str, Any]:
        bound: List[Dict[str, Any]] = []
        skipped: List[Dict[str, Any]] = []
        semantic_loss: List[Dict[str, Any]] = []
        for action in result.selected_actions:
            if not action.get("eligible_for_binding", False):
                skipped.append({"target": action["target"], "intent": action["intent"], "reason": action.get("ineligibility_reasons", [])})
                continue
            intent = BranchMultiplexer.to_generic_intent(action)
            output = self.adapter.bind_intent(intent)
            item = asdict(output)
            item["source_branches"] = action["source_branches"]
            item["audit_sidecar"] = {
                "reason": action.get("reason", ""),
                "confidence": action.get("confidence"),
                "source_message_ids": action.get("source_message_ids", []),
            }
            bound.append(item)
            semantic_loss.append({
                "source_message_ids": action.get("source_message_ids", []),
                "stage": "HOST_BINDING",
                "omitted_from_host_payload": ["reason", "confidence"],
                "audit_sidecar_fields": ["reason", "confidence", "source_message_ids"],
                "loss_class": "AUDIT_SIDECAR_ONLY",
            })
        return {"bound": bound, "skipped": skipped, "semantic_loss_ledger": semantic_loss}
