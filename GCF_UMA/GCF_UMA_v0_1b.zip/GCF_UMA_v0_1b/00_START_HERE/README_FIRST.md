# GCF-UMA v0.1b — Transactional Session, Replay Protection, and Failure Recovery

Status: `TRANSACTIONAL_SESSION_REPLAY_PROTECTION_FAILURE_RECOVERY_PASS`

GCF-UMA v0.1b extends the v0.1a branch-multiplexing and host-binding foundation with a deterministic transactional layer.

Validated capabilities in the locked mock harness:

- one active session per branch;
- monotonic sequence and duplicate/replay rejection;
- message freshness and explicit expiry;
- side-effect-free prepare;
- pending, approval, commit, abort, timeout, and rollback lifecycle;
- idempotent host execution;
- partial branch-outage isolation;
- pending-input supplementation after branch recovery;
- hash-chained audit receipts;
- preservation of v0.1/v0.1a capability, authority, role-isolation, and ramp rules.

This remains mock integration middleware. It is not a Safety Governor, a distributed consensus protocol, cryptographic authentication, or a production energy/6G transaction manager.
