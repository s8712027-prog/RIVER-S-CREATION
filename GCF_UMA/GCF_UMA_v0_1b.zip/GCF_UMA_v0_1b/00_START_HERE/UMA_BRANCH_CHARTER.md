# GCF-UMA Branch Charter — v0.1b

## Core responsibility

GCF-UMA is reusable integration middleware between GCF branch contracts, generic domain contracts, domain/host profiles, and transactional host binding.

## Locked branch roles

- OBS-CoreV2: evidence, observation requests, and bounded-policy advisories.
- AI-8: the only registered final action-intent provider in the current multiplex profile.
- BH: topology/margin annotation only.
- BCRC-PGRC: explicit certificate status only.
- GCF-UMA: contract validation, routing, provenance preservation, ambiguity blocking, transactional staging, and host binding.

## v0.1b transactional rule

A host-side effect may occur only after:

1. branch session and sequence validation;
2. replay, duplicate, timestamp, and expiry checks;
3. v0.1a role/contract/multiplex validation;
4. evidence/certificate eligibility checks;
5. side-effect-free host-binding preview;
6. required approval, if declared by the host profile;
7. explicit transaction commit.

Prepare, pending, abort, timeout, and rejected transactions must not modify the Adapter ramp state or Mock Host execution state.

## Non-responsibilities

- no structural-risk inference;
- no AI-8 route calculation;
- no BH margin calculation;
- no BCRC-PGRC certificate generation or independent truth validation;
- no Safety Governor authorization;
- no distributed consensus or two-phase commit across real hosts;
- no cryptographic identity or network-security guarantee;
- no domain optimization.
