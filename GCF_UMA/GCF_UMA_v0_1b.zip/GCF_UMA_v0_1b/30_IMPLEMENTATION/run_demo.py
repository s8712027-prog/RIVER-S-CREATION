from pathlib import Path
import json, sys
ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from gcf_uma import UniversalAdapter
from gcf_uma.models import GenericIntent

profiles = ROOT.parent / "20_PROFILES"
for profile_name, payload in [
    ("mock_energy_profile.yaml", {"timestamp":1,"entities":["device","critical_load"],"thermal_margin_pct":30,"electrical_headroom_kw":400,"coolant_temp_c":68,"critical_load_kw":220,"provenance":{"source_system":"energy_mock","source_identity":"bus_A"}}),
    ("mock_6g_profile.yaml", {"timestamp":1,"entities":["cell","urllc"],"prb_headroom_pct":35,"compute_headroom_gops":250,"sinr_db":16,"urllc_load_pct":60,"provenance":{"source_system":"ran_mock","source_identity":"feed_A"}}),
]:
    adapter = UniversalAdapter.from_yaml(profiles / profile_name)
    generic = adapter.to_generic(payload)
    bound = adapter.bind_intent(GenericIntent("REQUEST_OBSERVATION", "critical_state", 1.0, provenance={"branch":"OBS-CoreV2"}))
    print(json.dumps({"profile": profile_name, "generic": generic, "bound_output": bound.__dict__}, indent=2))
