from __future__ import annotations
from pathlib import Path
import json, sys

ROOT = Path(__file__).resolve().parent
PKG = ROOT.parent
sys.path.insert(0, str(ROOT))

from gcf_uma import AdapterHostPlugin, BranchEnvelope, BranchMultiplexer, ContractRegistry, UniversalAdapter

registry = ContractRegistry.from_directory(PKG / "15_BRANCH_CONTRACTS")
mux = BranchMultiplexer.from_yaml(registry, PKG / "20_PROFILES/branch_multiplex_profile.yaml")
energy = UniversalAdapter.from_yaml(PKG / "20_PROFILES/mock_energy_profile.yaml")
sixg = UniversalAdapter.from_yaml(PKG / "20_PROFILES/mock_6g_profile.yaml")

def env(message_id, branch, contract, version, message_type, payload, priority=50):
    return BranchEnvelope(message_id, branch, contract, version, message_type, payload, priority, {"formal_gate": True})

def evidence(support="SUPPORTED"):
    return env("obs-evidence", "OBS-CoreV2", "GCF_OBS_COREV2_ADAPTER_CONTRACT", "0.1k", "EVIDENCE_STATUS", {"support_class":support,"uncertainty":0.12,"source_diversity":0.84}, 90)

def cert(state="VALID", scope="critical_load"):
    return env("certificate", "BCRC-PGRC", "GCF_BCRC_PGRC_CERTIFICATE_CONTRACT", "1.0", "CERTIFICATE_STATUS", {"certificate_id":"formal-cert","state":state,"scope":scope,"reason":"formal explicit status"}, 95)

def ai(intent="PROTECT_CRITICAL", target="critical_load", mag=0.18, mid="ai-action"):
    return env(mid, "AI-8", "GCF_AI8_ACTION_ROUTER_CONTRACT", "0.5d", "ACTION_INTENT", {"intent":intent,"target":target,"magnitude":mag,"reason":"AI-8 explicit route","confidence":0.88}, 80)

def obs_action(intent="PROTECT_CRITICAL", target="critical_load", mag=0.12, mid="obs-action"):
    return env(mid, "OBS-CoreV2", "GCF_OBS_COREV2_ADAPTER_CONTRACT", "0.1k", "BOUNDED_RESCUE_INTENT", {"intent":intent,"target":target,"magnitude":mag,"reason":"OBS bounded policy"}, 70)

results = {}

neg = {
    "OBS-CoreV2": registry.negotiate("OBS-CoreV2", "GCF_OBS_COREV2_ADAPTER_CONTRACT", ["0.1j", "0.1k"]).__dict__,
    "AI-8": registry.negotiate("AI-8", "GCF_AI8_ACTION_ROUTER_CONTRACT", ["0.5c", "0.5d"]).__dict__,
    "BH": registry.negotiate("BH", "GCF_BH_TOPOLOGY_MARGIN_CONTRACT", ["PROV8A-v1.1"]).__dict__,
    "BCRC-PGRC": registry.negotiate("BCRC-PGRC", "GCF_BCRC_PGRC_CERTIFICATE_CONTRACT", ["1.0"]).__dict__,
}
results["M1"] = {"pass": all(v["state"] == "NEGOTIATED" for v in neg.values()), "detail": neg}
unknown = registry.negotiate("UNKNOWN", "X", ["1.0"]).__dict__
incompat = registry.negotiate("OBS-CoreV2", "GCF_OBS_COREV2_ADAPTER_CONTRACT", ["0.1i"]).__dict__
results["M2"] = {"pass": unknown["state"] == "UNKNOWN_BRANCH" and incompat["state"] == "NO_COMMON_VERSION", "detail": {"unknown":unknown,"incompatible":incompat}}

malicious_bh = env("bh-inject", "BH", "GCF_BH_TOPOLOGY_MARGIN_CONTRACT", "PROV8A-v1.1", "ACTION_INTENT", {"intent":"PROTECT_CRITICAL","target":"critical_load","magnitude":1.0})
role_result = mux.process([malicious_bh])
results["M3"] = {"pass": len(role_result.action_candidates) == 0 and len(role_result.rejected_messages) == 1, "detail": role_result.to_dict()}

req_low = env("req-low", "OBS-CoreV2", "GCF_OBS_COREV2_ADAPTER_CONTRACT", "0.1k", "OBSERVATION_REQUEST", {"target":"noncritical","priority":1,"expected_information_value":0.2}, 10)
req_high = env("req-high", "OBS-CoreV2", "GCF_OBS_COREV2_ADAPTER_CONTRACT", "0.1k", "OBSERVATION_REQUEST", {"target":"critical","priority":9,"expected_information_value":0.8}, 90)
order_result = mux.process([req_low, req_high])
results["M4"] = {"pass": [x["message_id"] for x in order_result.observation_requests] == ["req-high","req-low"], "detail": order_result.to_dict()}

merge_result = mux.process([evidence(), cert(), obs_action(), ai()])
merged = merge_result.selected_actions[0]
results["M5"] = {"pass": len(merge_result.policy_advisories) == 1 and merged["source_branches"] == ["AI-8"] and merged["eligible_for_binding"], "detail": merge_result.to_dict()}

conflict_result = mux.process([evidence(), cert(), ai(intent="HOLD", mid="ai-hold"), ai(intent="PROTECT_CRITICAL", mid="ai-protect")])
results["M6"] = {"pass": len(conflict_result.conflicts) == 1 and len(conflict_result.selected_actions) == 0, "detail": conflict_result.to_dict()}

support_result = mux.process([evidence("UNSUPPORTED"), cert(), ai()])
results["M7"] = {"pass": not support_result.selected_actions[0]["eligible_for_binding"], "detail": support_result.to_dict()}

cert_result = mux.process([evidence(), cert("INVALID"), ai()])
results["M8"] = {"pass": not cert_result.selected_actions[0]["eligible_for_binding"], "detail": cert_result.to_dict()}

prov_result = mux.process([evidence()])
results["M9"] = {"pass": prov_result.evidence[0]["provenance"]["adapter_branch_namespace"] == "OBS-CoreV2", "detail": prov_result.to_dict()}

bound_merge = AdapterHostPlugin(energy).bind(merge_result)
sidecar = bound_merge["bound"][0]["audit_sidecar"]
results["M10"] = {"pass": sidecar["reason"] == "AI-8 explicit route" and sidecar["confidence"] == 0.88 and bound_merge["semantic_loss_ledger"][0]["loss_class"] == "AUDIT_SIDECAR_ONLY", "detail": bound_merge}

approval_result = mux.process([evidence(), cert(), ai(intent="ADJUST_ALLOCATION", mag=0.1)])
approval_bound = AdapterHostPlugin(energy).bind(approval_result)
results["M11"] = {"pass": approval_bound["bound"][0]["authority_mode"] == "APPROVAL_REQUIRED" and not approval_bound["bound"][0]["executable"], "detail": approval_bound}

obs_request_action = mux.process([evidence("UNSUPPORTED"), ai(intent="REQUEST_OBSERVATION", target="telemetry", mag=1.0)])
ebound = AdapterHostPlugin(UniversalAdapter.from_yaml(PKG / "20_PROFILES/mock_energy_profile.yaml")).bind(obs_request_action)
rbound = AdapterHostPlugin(UniversalAdapter.from_yaml(PKG / "20_PROFILES/mock_6g_profile.yaml")).bind(obs_request_action)
results["M12"] = {"pass": ebound["bound"][0]["host_operation"] == "energy.request_sensor_refresh" and rbound["bound"][0]["host_operation"] == "ran.request_measurement_report", "detail": {"energy":ebound,"sixg":rbound}}

invalid_ai = env("bad-ai", "AI-8", "GCF_AI8_ACTION_ROUTER_CONTRACT", "0.5d", "ACTION_INTENT", {"intent":"HOLD"}, 80)
isolation_result = mux.process([evidence(), invalid_ai])
results["M13"] = {"pass": len(isolation_result.evidence) == 1 and len(isolation_result.rejected_messages) == 1, "detail": isolation_result.to_dict()}

bh_high = env("bh-high", "BH", "GCF_BH_TOPOLOGY_MARGIN_CONTRACT", "PROV8A-v1.1", "TOPOLOGY_MARGIN", {"boundary_proximity":0.99,"margin_remaining":0.01,"transition_risk":0.99,"provenance_class":"REDUCED_ORDER_BH_PRIOR","confidence":0.99}, 100)
hidden_logic = mux.process([bh_high])
results["M14"] = {"pass": len(hidden_logic.annotations) == 1 and len(hidden_logic.action_candidates) == 0 and len(hidden_logic.selected_actions) == 0, "detail": hidden_logic.to_dict()}

verdict = "PASS" if all(v["pass"] for v in results.values()) else "FAIL"
output = {
    "version": "GCF-UMA-v0.1a",
    "status": "BRANCH_MULTIPLEXING_CONTRACT_NEGOTIATION_PASS" if verdict == "PASS" else "BRANCH_MULTIPLEXING_CONTRACT_NEGOTIATION_FAIL",
    "verdict": verdict,
    "passed": sum(1 for v in results.values() if v["pass"]),
    "total": len(results),
    "gates": results,
}
print(json.dumps(output, indent=2))
