from pathlib import Path
import json, sys

ROOT = Path(__file__).resolve().parent
PKG = ROOT.parent
sys.path.insert(0, str(ROOT))

from gcf_uma import AdapterHostPlugin, BranchEnvelope, BranchMultiplexer, ContractRegistry, UniversalAdapter

registry = ContractRegistry.from_directory(PKG / "15_BRANCH_CONTRACTS")
mux = BranchMultiplexer.from_yaml(registry, PKG / "20_PROFILES/branch_multiplex_profile.yaml")
adapter = UniversalAdapter.from_yaml(PKG / "20_PROFILES/mock_energy_profile.yaml")

envelopes = [
    BranchEnvelope("obs-1", "OBS-CoreV2", "GCF_OBS_COREV2_ADAPTER_CONTRACT", "0.1k", "EVIDENCE_STATUS", {"support_class":"SUPPORTED","uncertainty":0.12,"source_diversity":0.85}, 90, {"run":"demo"}),
    BranchEnvelope("obs-2", "OBS-CoreV2", "GCF_OBS_COREV2_ADAPTER_CONTRACT", "0.1k", "BOUNDED_RESCUE_INTENT", {"intent":"PROTECT_CRITICAL","target":"critical_load","magnitude":0.18,"reason":"structural burden rising"}, 70, {"run":"demo"}),
    BranchEnvelope("ai8-1", "AI-8", "GCF_AI8_ACTION_ROUTER_CONTRACT", "0.5d", "ACTION_INTENT", {"intent":"PROTECT_CRITICAL","target":"critical_load","magnitude":0.18,"reason":"evidence-to-action route","confidence":0.88}, 80, {"run":"demo"}),
    BranchEnvelope("bh-1", "BH", "GCF_BH_TOPOLOGY_MARGIN_CONTRACT", "PROV8A-v1.1", "TOPOLOGY_MARGIN", {"boundary_proximity":0.72,"margin_remaining":0.28,"transition_risk":0.67,"provenance_class":"REDUCED_ORDER_BH_PRIOR","confidence":0.61}, 40, {"run":"demo"}),
    BranchEnvelope("cert-1", "BCRC-PGRC", "GCF_BCRC_PGRC_CERTIFICATE_CONTRACT", "1.0", "CERTIFICATE_STATUS", {"certificate_id":"cert-demo","state":"VALID","scope":"critical_load","reason":"locked synthetic certificate"}, 95, {"run":"demo"}),
]
result = mux.process(envelopes)
bound = AdapterHostPlugin(adapter).bind(result)
print(json.dumps({"multiplex": result.to_dict(), "host_binding": bound}, indent=2))
