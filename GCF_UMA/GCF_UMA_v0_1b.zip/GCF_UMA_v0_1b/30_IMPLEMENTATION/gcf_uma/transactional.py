from __future__ import annotations

from copy import deepcopy
from dataclasses import asdict
import hashlib
import json
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional
import yaml

from .host_plugin import AdapterHostPlugin
from .models import BranchEnvelope, TransactionRecord
from .multiplexer import BranchMultiplexer


class TransactionError(ValueError):
    pass


def _stable_hash(payload: Dict[str, Any]) -> str:
    raw = json.dumps(payload, sort_keys=True, separators=(",", ":"), default=str).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


class SessionReplayGuard:
    """Transport/session validation only; it does not inspect branch semantics."""

    def __init__(self, profile: Dict[str, Any]):
        self.profile = deepcopy(profile)
        self.active_sessions: Dict[str, str] = {}
        self.retired_sessions: Dict[str, set[str]] = {}
        self.last_sequence: Dict[tuple[str, str], int] = {}
        self.seen_message_ids: set[tuple[str, str, str]] = set()

    @classmethod
    def from_yaml(cls, path: str | Path) -> "SessionReplayGuard":
        with open(path, "r", encoding="utf-8") as f:
            return cls(yaml.safe_load(f))

    def open_session(self, branch_id: str, session_id: str) -> None:
        if not session_id:
            raise TransactionError("session_id must be non-empty")
        previous = self.active_sessions.get(branch_id)
        if previous and previous != session_id:
            self.retired_sessions.setdefault(branch_id, set()).add(previous)
        if session_id in self.retired_sessions.get(branch_id, set()):
            raise TransactionError("retired session cannot be reopened")
        self.active_sessions[branch_id] = session_id
        self.last_sequence.setdefault((branch_id, session_id), 0)

    def validate(self, envelope: BranchEnvelope, now: float) -> Dict[str, Any]:
        if not envelope.session_id:
            return {"accepted": False, "reason": "MISSING_SESSION_ID"}
        active = self.active_sessions.get(envelope.branch_id)
        if active is None:
            return {"accepted": False, "reason": "SESSION_NOT_OPEN"}
        if envelope.session_id != active:
            reason = "RETIRED_SESSION" if envelope.session_id in self.retired_sessions.get(envelope.branch_id, set()) else "SESSION_MISMATCH"
            return {"accepted": False, "reason": reason}
        if envelope.sequence < 1:
            return {"accepted": False, "reason": "INVALID_SEQUENCE"}
        key = (envelope.branch_id, envelope.session_id)
        message_key = (envelope.branch_id, envelope.session_id, envelope.message_id)
        if message_key in self.seen_message_ids:
            return {"accepted": False, "reason": "DUPLICATE_MESSAGE"}
        if envelope.sequence <= self.last_sequence.get(key, 0):
            return {"accepted": False, "reason": "REPLAY_OR_OUT_OF_ORDER"}
        skew = float(self.profile.get("max_future_clock_skew", 0.0))
        if envelope.issued_at <= 0:
            return {"accepted": False, "reason": "MISSING_ISSUED_AT"}
        if envelope.issued_at > now + skew:
            return {"accepted": False, "reason": "FUTURE_TIMESTAMP"}
        if envelope.expires_at is not None and now > float(envelope.expires_at):
            return {"accepted": False, "reason": "EXPIRED_MESSAGE"}
        max_age = self.profile.get("max_age_by_message_type", {}).get(envelope.message_type)
        if max_age is not None and now - envelope.issued_at > float(max_age):
            return {"accepted": False, "reason": "STALE_MESSAGE"}
        self.last_sequence[key] = envelope.sequence
        self.seen_message_ids.add(message_key)
        return {"accepted": True, "reason": "ACCEPTED"}


class MockBranchTransport:
    """Deterministic transport/outage harness, not a production transport."""

    def __init__(self):
        self.online: Dict[str, bool] = {}

    def set_online(self, branch_id: str, online: bool) -> None:
        self.online[branch_id] = bool(online)

    def deliver(self, envelopes: Iterable[BranchEnvelope]) -> tuple[List[BranchEnvelope], List[Dict[str, Any]]]:
        delivered: List[BranchEnvelope] = []
        dropped: List[Dict[str, Any]] = []
        for envelope in envelopes:
            if self.online.get(envelope.branch_id, True):
                delivered.append(envelope)
            else:
                dropped.append({"message_id": envelope.message_id, "branch_id": envelope.branch_id, "reason": "BRANCH_OFFLINE"})
        return delivered, dropped


class MockTransactionalHost:
    def __init__(self, rollback_bindings: Optional[Dict[str, str]] = None):
        self.rollback_bindings = rollback_bindings or {}
        self.executions: Dict[str, Dict[str, Any]] = {}
        self.idempotency_index: Dict[str, str] = {}
        self.execution_order: List[str] = []

    def execute(self, bound_output: Dict[str, Any], idempotency_key: str, now: float) -> Dict[str, Any]:
        if idempotency_key in self.idempotency_index:
            existing = deepcopy(self.executions[self.idempotency_index[idempotency_key]])
            existing["idempotent_replay"] = True
            return existing
        execution_id = f"exec-{len(self.executions)+1:04d}"
        receipt = {
            "execution_id": execution_id,
            "idempotency_key": idempotency_key,
            "host_operation": bound_output["host_operation"],
            "target": bound_output["target"],
            "magnitude": bound_output["magnitude"],
            "executed_at": now,
            "state": "EXECUTED",
            "idempotent_replay": False,
        }
        self.executions[execution_id] = deepcopy(receipt)
        self.idempotency_index[idempotency_key] = execution_id
        self.execution_order.append(execution_id)
        return receipt

    def rollback(self, execution_id: str, now: float) -> Dict[str, Any]:
        if execution_id not in self.executions:
            raise TransactionError("unknown execution_id")
        execution = self.executions[execution_id]
        if execution.get("state") == "ROLLED_BACK":
            return deepcopy(execution["rollback_receipt"])
        operation = execution["host_operation"]
        if operation not in self.rollback_bindings:
            raise TransactionError(f"operation is not reversible: {operation}")
        receipt = {
            "execution_id": execution_id,
            "rollback_operation": self.rollback_bindings[operation],
            "rolled_back_at": now,
            "state": "ROLLED_BACK",
        }
        execution["state"] = "ROLLED_BACK"
        execution["rollback_receipt"] = deepcopy(receipt)
        return receipt


class TransactionCoordinator:
    def __init__(
        self,
        multiplexer: BranchMultiplexer,
        host_plugin: AdapterHostPlugin,
        replay_guard: SessionReplayGuard,
        host: MockTransactionalHost,
        profile: Dict[str, Any],
        transport: Optional[MockBranchTransport] = None,
    ):
        self.multiplexer = multiplexer
        self.host_plugin = host_plugin
        self.replay_guard = replay_guard
        self.host = host
        self.profile = deepcopy(profile)
        self.transport = transport or MockBranchTransport()
        self.transactions: Dict[str, TransactionRecord] = {}
        self._transaction_inputs: Dict[str, List[BranchEnvelope]] = {}
        self.receipt_chain: List[Dict[str, Any]] = []

    @classmethod
    def from_yaml(
        cls,
        multiplexer: BranchMultiplexer,
        host_plugin: AdapterHostPlugin,
        replay_guard: SessionReplayGuard,
        host: MockTransactionalHost,
        path: str | Path,
        transport: Optional[MockBranchTransport] = None,
    ) -> "TransactionCoordinator":
        with open(path, "r", encoding="utf-8") as f:
            return cls(multiplexer, host_plugin, replay_guard, host, yaml.safe_load(f), transport)

    def open_session(self, branch_id: str, session_id: str) -> None:
        self.replay_guard.open_session(branch_id, session_id)

    def _append_receipt(self, body: Dict[str, Any]) -> Dict[str, Any]:
        prior = self.receipt_chain[-1]["receipt_hash"] if self.receipt_chain else "GENESIS"
        material = {**deepcopy(body), "previous_receipt_hash": prior}
        material["receipt_hash"] = _stable_hash(material)
        self.receipt_chain.append(deepcopy(material))
        return material

    def _transport_validate(self, envelopes: Iterable[BranchEnvelope], now: float) -> tuple[List[BranchEnvelope], List[Dict[str, Any]]]:
        delivered, dropped = self.transport.deliver(envelopes)
        accepted: List[BranchEnvelope] = []
        rejected = list(dropped)
        for envelope in delivered:
            decision = self.replay_guard.validate(envelope, now)
            if decision["accepted"]:
                accepted.append(envelope)
            else:
                rejected.append({"message_id": envelope.message_id, "branch_id": envelope.branch_id, "reason": decision["reason"]})
        return accepted, rejected

    def _input_valid_until(self, envelopes: Iterable[BranchEnvelope]) -> float:
        deadlines: List[float] = []
        max_age_by_type = self.replay_guard.profile.get("max_age_by_message_type", {})
        for envelope in envelopes:
            if envelope.expires_at is not None:
                deadlines.append(float(envelope.expires_at))
            elif envelope.message_type in max_age_by_type:
                deadlines.append(float(envelope.issued_at) + float(max_age_by_type[envelope.message_type]))
        return min(deadlines) if deadlines else float("inf")

    @staticmethod
    def _derive_state(mux_result, preview: Dict[str, Any]) -> tuple[str, str]:
        if mux_result.conflicts:
            return "ABORTED", "MULTIPLEX_CONFLICT"
        if not preview["bound"]:
            return ("PENDING_INPUT", "") if mux_result.accepted_message_ids else ("ABORTED", "NO_ACCEPTED_MESSAGES")
        if any(item["approval_required"] for item in preview["bound"]):
            return "PENDING_APPROVAL", ""
        if all(item["executable"] for item in preview["bound"]):
            return "PREPARED", ""
        return "PENDING_AUTHORITY", ""

    def begin(self, transaction_id: str, envelopes: Iterable[BranchEnvelope], now: float, timeout: Optional[float] = None) -> TransactionRecord:
        if transaction_id in self.transactions:
            raise TransactionError("transaction_id already exists")
        timeout_value = float(timeout if timeout is not None else self.profile.get("default_timeout", 5.0))
        accepted, transport_rejections = self._transport_validate(envelopes, now)
        mux_result = self.multiplexer.process(accepted)
        preview = self.host_plugin.bind(mux_result, commit_state=False)
        state, abort_reason = self._derive_state(mux_result, preview)
        input_valid_until = self._input_valid_until(accepted)
        record = TransactionRecord(
            transaction_id=transaction_id,
            state=state,
            created_at=now,
            deadline=min(now + timeout_value, input_valid_until),
            selected_actions=deepcopy(mux_result.selected_actions),
            preview_binding=deepcopy(preview),
            transport_rejections=deepcopy(transport_rejections),
            multiplex_result=mux_result.to_dict(),
            abort_reason=abort_reason,
        )
        self.transactions[transaction_id] = record
        self._transaction_inputs[transaction_id] = list(accepted)
        return record

    def supplement(self, transaction_id: str, envelopes: Iterable[BranchEnvelope], now: float) -> TransactionRecord:
        if transaction_id not in self.transactions:
            raise TransactionError("unknown transaction")
        record = self.transactions[transaction_id]
        if record.state not in ("PENDING_INPUT", "PENDING_APPROVAL", "PENDING_AUTHORITY"):
            raise TransactionError(f"transaction cannot be supplemented from {record.state}")
        if now > record.deadline:
            record.state = "TIMED_OUT"
            record.abort_reason = "DEADLINE_EXCEEDED"
            record.commit_receipt = self._append_receipt({"transaction_id": transaction_id, "state": "TIMED_OUT", "time": now, "executions": []})
            return record
        accepted, rejections = self._transport_validate(envelopes, now)
        record.transport_rejections.extend(deepcopy(rejections))
        combined = self._transaction_inputs.get(transaction_id, []) + accepted
        self._transaction_inputs[transaction_id] = combined
        mux_result = self.multiplexer.process(combined)
        preview = self.host_plugin.bind(mux_result, commit_state=False)
        state, abort_reason = self._derive_state(mux_result, preview)
        record.state = state
        record.abort_reason = abort_reason
        record.selected_actions = deepcopy(mux_result.selected_actions)
        record.preview_binding = deepcopy(preview)
        record.multiplex_result = mux_result.to_dict()
        record.deadline = min(record.deadline, self._input_valid_until(combined))
        return record

    def commit(self, transaction_id: str, now: float, approval: bool = False) -> Dict[str, Any]:
        if transaction_id not in self.transactions:
            raise TransactionError("unknown transaction")
        record = self.transactions[transaction_id]
        if record.state == "COMMITTED":
            receipt = deepcopy(record.commit_receipt or {})
            receipt["idempotent_replay"] = True
            return receipt
        if record.state in ("ABORTED", "TIMED_OUT", "ROLLED_BACK"):
            raise TransactionError(f"transaction cannot commit from {record.state}")
        if now > record.deadline:
            record.state = "TIMED_OUT"
            record.abort_reason = "DEADLINE_EXCEEDED"
            receipt = self._append_receipt({"transaction_id": transaction_id, "state": "TIMED_OUT", "time": now, "executions": []})
            record.commit_receipt = deepcopy(receipt)
            return receipt
        if record.state == "PENDING_APPROVAL" and not approval:
            raise TransactionError("approval required")
        if record.state in ("PENDING_INPUT", "PENDING_AUTHORITY"):
            raise TransactionError(f"transaction is not commit-ready: {record.state}")
        # Reconstruct a MultiplexResult-compatible object by reusing the stored selected actions.
        from .models import MultiplexResult
        mux = MultiplexResult(status=record.multiplex_result.get("status", "PASS"))
        mux.selected_actions = deepcopy(record.selected_actions)
        actual_binding = self.host_plugin.bind(mux, commit_state=True)
        executions: List[Dict[str, Any]] = []
        for index, item in enumerate(actual_binding["bound"]):
            item = deepcopy(item)
            item["approval_granted"] = bool(approval and item.get("approval_required"))
            key = _stable_hash({"transaction_id": transaction_id, "index": index, "operation": item["host_operation"], "target": item["target"]})
            executions.append(self.host.execute(item, key, now))
        state = "COMMITTED" if executions else "ABORTED"
        record.state = state
        body = {
            "transaction_id": transaction_id,
            "state": state,
            "time": now,
            "executions": executions,
            "binding": actual_binding,
            "idempotent_replay": False,
        }
        receipt = self._append_receipt(body)
        record.commit_receipt = deepcopy(receipt)
        if state == "ABORTED":
            record.abort_reason = "NO_EXECUTABLE_BINDING"
        return receipt

    def abort(self, transaction_id: str, now: float, reason: str) -> Dict[str, Any]:
        if transaction_id not in self.transactions:
            raise TransactionError("unknown transaction")
        record = self.transactions[transaction_id]
        if record.state == "COMMITTED":
            raise TransactionError("committed transaction requires rollback")
        if record.state == "ABORTED":
            return deepcopy(record.commit_receipt or {"transaction_id": transaction_id, "state": "ABORTED", "idempotent_replay": True})
        record.state = "ABORTED"
        record.abort_reason = reason
        receipt = self._append_receipt({"transaction_id": transaction_id, "state": "ABORTED", "time": now, "reason": reason, "executions": []})
        record.commit_receipt = deepcopy(receipt)
        return receipt

    def rollback(self, transaction_id: str, now: float) -> Dict[str, Any]:
        if transaction_id not in self.transactions:
            raise TransactionError("unknown transaction")
        record = self.transactions[transaction_id]
        if record.state == "ROLLED_BACK":
            receipt = deepcopy(record.rollback_receipt or {})
            receipt["idempotent_replay"] = True
            return receipt
        if record.state != "COMMITTED" or not record.commit_receipt:
            raise TransactionError("only committed transactions can be rolled back")
        rollbacks = []
        for execution in record.commit_receipt.get("executions", []):
            rollbacks.append(self.host.rollback(execution["execution_id"], now))
        record.state = "ROLLED_BACK"
        receipt = self._append_receipt({"transaction_id": transaction_id, "state": "ROLLED_BACK", "time": now, "rollbacks": rollbacks, "idempotent_replay": False})
        record.rollback_receipt = deepcopy(receipt)
        return receipt

    def expire_pending(self, now: float) -> List[str]:
        expired = []
        for transaction_id, record in self.transactions.items():
            if record.state in ("PREPARED", "PENDING_INPUT", "PENDING_APPROVAL", "PENDING_AUTHORITY") and now > record.deadline:
                record.state = "TIMED_OUT"
                record.abort_reason = "DEADLINE_EXCEEDED"
                record.commit_receipt = self._append_receipt({"transaction_id": transaction_id, "state": "TIMED_OUT", "time": now, "executions": []})
                expired.append(transaction_id)
        return expired

    def verify_receipt_chain(self) -> bool:
        prior = "GENESIS"
        for receipt in self.receipt_chain:
            if receipt.get("previous_receipt_hash") != prior:
                return False
            expected = deepcopy(receipt)
            actual_hash = expected.pop("receipt_hash", None)
            if _stable_hash(expected) != actual_hash:
                return False
            prior = actual_hash
        return True
