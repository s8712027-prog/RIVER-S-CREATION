from __future__ import annotations
from pathlib import Path
from typing import Any, Dict, Iterable
import re
import yaml

from .models import BranchEnvelope, NegotiationResult

class ContractError(ValueError):
    pass


def _version_key(value: str) -> tuple:
    parts = re.findall(r"\d+|[A-Za-z]+", value)
    key = []
    for part in parts:
        key.append((0, int(part)) if part.isdigit() else (1, part.lower()))
    return tuple(key)


class ContractRegistry:
    def __init__(self, contracts: Dict[str, Dict[str, Any]]):
        self.contracts = contracts

    @classmethod
    def from_directory(cls, directory: str | Path) -> "ContractRegistry":
        directory = Path(directory)
        contracts: Dict[str, Dict[str, Any]] = {}
        for path in sorted(directory.glob("*.yaml")):
            with open(path, "r", encoding="utf-8") as f:
                spec = yaml.safe_load(f)
            branch_id = spec.get("branch_id")
            if not branch_id:
                raise ContractError(f"contract missing branch_id: {path}")
            if branch_id in contracts:
                raise ContractError(f"duplicate branch contract: {branch_id}")
            contracts[branch_id] = spec
        return cls(contracts)

    def negotiate(self, branch_id: str, contract_id: str, offered_versions: Iterable[str]) -> NegotiationResult:
        if branch_id not in self.contracts:
            return NegotiationResult(branch_id, "UNKNOWN_BRANCH", reason="branch contract not registered")
        spec = self.contracts[branch_id]
        if contract_id != spec["contract_id"]:
            return NegotiationResult(branch_id, "CONTRACT_ID_MISMATCH", reason="contract_id does not match registered branch")
        common = sorted(set(offered_versions).intersection(spec.get("supported_versions", [])), key=_version_key)
        if not common:
            return NegotiationResult(branch_id, "NO_COMMON_VERSION", reason="no exact common contract version")
        return NegotiationResult(branch_id, "NEGOTIATED", selected_version=common[-1])

    def validate_envelope(self, envelope: BranchEnvelope) -> Dict[str, Any]:
        if envelope.branch_id not in self.contracts:
            raise ContractError(f"unknown branch: {envelope.branch_id}")
        spec = self.contracts[envelope.branch_id]
        if envelope.contract_id != spec["contract_id"]:
            raise ContractError(f"contract id mismatch for {envelope.branch_id}")
        if envelope.contract_version not in spec.get("supported_versions", []):
            raise ContractError(f"unsupported contract version for {envelope.branch_id}: {envelope.contract_version}")
        message_specs = spec.get("message_types", {})
        if envelope.message_type not in message_specs:
            raise ContractError(f"message type not allowed for branch {envelope.branch_id}: {envelope.message_type}")
        if not (0 <= int(envelope.priority) <= 100):
            raise ContractError("priority must be in [0,100]")
        msg_spec = message_specs[envelope.message_type]
        missing = [field for field in msg_spec.get("required", []) if field not in envelope.payload]
        if missing:
            raise ContractError(f"payload missing fields: {missing}")
        for field, allowed in msg_spec.get("enums", {}).items():
            if envelope.payload.get(field) not in allowed:
                raise ContractError(f"invalid {field}: {envelope.payload.get(field)}")
        return spec
