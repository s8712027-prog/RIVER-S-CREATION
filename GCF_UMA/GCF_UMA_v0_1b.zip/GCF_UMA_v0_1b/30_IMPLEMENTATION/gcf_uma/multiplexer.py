from __future__ import annotations
from copy import deepcopy
from pathlib import Path
from typing import Any, Dict, Iterable, List
import yaml

from .contracts import ContractError, ContractRegistry
from .models import BranchEnvelope, GenericIntent, MultiplexResult

class MultiplexError(ValueError):
    pass


class BranchMultiplexer:
    def __init__(self, registry: ContractRegistry, profile: Dict[str, Any]):
        self.registry = registry
        self.profile = deepcopy(profile)
        for key in ("profile_id", "routes", "binding_preconditions", "conflict_policy"):
            if key not in self.profile:
                raise MultiplexError(f"multiplex profile missing: {key}")

    @classmethod
    def from_yaml(cls, registry: ContractRegistry, path: str | Path) -> "BranchMultiplexer":
        with open(path, "r", encoding="utf-8") as f:
            return cls(registry, yaml.safe_load(f))

    def _route(self, envelope: BranchEnvelope) -> str:
        branch_routes = self.profile["routes"].get(envelope.branch_id, {})
        if envelope.message_type not in branch_routes:
            raise MultiplexError(f"no route for {envelope.branch_id}/{envelope.message_type}")
        return branch_routes[envelope.message_type]

    @staticmethod
    def _sidecar(envelope: BranchEnvelope, stage: str, loss_class: str = "LOSSLESS", omitted: List[str] | None = None) -> Dict[str, Any]:
        omitted = omitted or []
        return {
            "message_id": envelope.message_id,
            "source_branch": envelope.branch_id,
            "stage": stage,
            "preserved_fields": sorted(envelope.payload.keys()),
            "transformed_fields": [],
            "omitted_from_host_payload": omitted,
            "audit_sidecar_fields": omitted,
            "loss_class": loss_class,
        }

    def process(self, envelopes: Iterable[BranchEnvelope]) -> MultiplexResult:
        result = MultiplexResult(status="PASS")
        routed: Dict[str, List[Dict[str, Any]]] = {k: [] for k in ("evidence", "observation_request", "policy_advisory", "annotation", "certificate", "action_candidate")}
        for envelope in sorted(envelopes, key=lambda e: (-e.priority, e.message_id)):
            try:
                self.registry.validate_envelope(envelope)
                route = self._route(envelope)
            except (ContractError, MultiplexError) as exc:
                result.rejected_messages.append({"message_id": envelope.message_id, "branch_id": envelope.branch_id, "reason": str(exc)})
                result.semantic_loss_ledger.append({
                    "message_id": envelope.message_id,
                    "source_branch": envelope.branch_id,
                    "stage": "VALIDATION",
                    "preserved_fields": [],
                    "transformed_fields": [],
                    "omitted_from_host_payload": sorted(envelope.payload.keys()),
                    "audit_sidecar_fields": [],
                    "loss_class": "REJECTED_UNSUPPORTED",
                })
                continue
            item = {
                "message_id": envelope.message_id,
                "branch_id": envelope.branch_id,
                "priority": envelope.priority,
                "payload": deepcopy(envelope.payload),
                "provenance": {**deepcopy(envelope.provenance), "adapter_branch_namespace": envelope.branch_id},
            }
            routed[route].append(item)
            result.accepted_message_ids.append(envelope.message_id)
            result.semantic_loss_ledger.append(self._sidecar(envelope, "MULTIPLEX_STAGING"))

        result.evidence = routed["evidence"]
        result.observation_requests = routed["observation_request"]
        result.policy_advisories = routed["policy_advisory"]
        result.annotations = routed["annotation"]
        result.certificates = routed["certificate"]
        result.action_candidates = routed["action_candidate"]

        support = result.evidence[0]["payload"].get("support_class") if result.evidence else "ABSENT"
        cert_by_scope: Dict[str, str] = {}
        for item in result.certificates:
            cert_by_scope[item["payload"]["scope"]] = item["payload"]["state"]

        groups: Dict[str, List[Dict[str, Any]]] = {}
        for item in result.action_candidates:
            target = item["payload"]["target"]
            groups.setdefault(target, []).append(item)

        for target, candidates in sorted(groups.items()):
            intents = {c["payload"]["intent"] for c in candidates}
            magnitudes = {float(c["payload"].get("magnitude", 0.0)) for c in candidates}
            merge_mismatch = len(intents) == 1 and len(magnitudes) > 1 and self.profile.get("identical_intent_merge") == "REQUIRE_EQUAL_MAGNITUDE"
            if len(intents) > 1 or merge_mismatch:
                conflict = {
                    "target": target,
                    "intents": sorted(intents),
                    "magnitudes": sorted(magnitudes),
                    "message_ids": [c["message_id"] for c in candidates],
                    "policy": self.profile["conflict_policy"] if len(intents) > 1 else self.profile.get("identical_intent_merge"),
                }
                result.conflicts.append(conflict)
                for c in candidates:
                    result.semantic_loss_ledger.append({
                        "message_id": c["message_id"],
                        "source_branch": c["branch_id"],
                        "stage": "CONFLICT_RESOLUTION",
                        "preserved_fields": sorted(c["payload"].keys()),
                        "transformed_fields": [],
                        "omitted_from_host_payload": sorted(c["payload"].keys()),
                        "audit_sidecar_fields": sorted(c["payload"].keys()),
                        "loss_class": "REJECTED_CONFLICT",
                    })
                continue
            intent_name = next(iter(intents))
            chosen = max(candidates, key=lambda c: (float(c["payload"].get("magnitude", 0.0)), c["priority"], c["message_id"]))
            merged_sources = sorted({c["branch_id"] for c in candidates})
            magnitude = float(chosen["payload"].get("magnitude", 0.0))
            pre = self.profile["binding_preconditions"].get(intent_name)
            if pre is None:
                eligible = False
                reasons = ["no binding precondition declared"]
            else:
                certificate = cert_by_scope.get(target, cert_by_scope.get("*", "ABSENT"))
                reasons = []
                if support not in pre.get("allowed_support", []):
                    reasons.append(f"support={support} not allowed")
                if certificate not in pre.get("allowed_certificate", []):
                    reasons.append(f"certificate={certificate} not allowed")
                eligible = not reasons
            selected = {
                "intent": intent_name,
                "target": target,
                "magnitude": magnitude,
                "reason": chosen["payload"].get("reason", ""),
                "confidence": chosen["payload"].get("confidence"),
                "source_branches": merged_sources,
                "source_message_ids": [c["message_id"] for c in candidates],
                "eligible_for_binding": eligible,
                "ineligibility_reasons": reasons,
                "provenance": {
                    "multiplex_profile_id": self.profile["profile_id"],
                    "source_branches": merged_sources,
                    "source_message_ids": [c["message_id"] for c in candidates],
                },
            }
            result.selected_actions.append(selected)

        if result.conflicts or any(not x["eligible_for_binding"] for x in result.selected_actions):
            result.status = "PARTIAL"
        if not result.accepted_message_ids:
            result.status = "REJECTED"
        result.audit = {
            "multiplex_profile_id": self.profile["profile_id"],
            "support_class_used": support,
            "certificate_scopes": cert_by_scope,
            "accepted_count": len(result.accepted_message_ids),
            "rejected_count": len(result.rejected_messages),
            "conflict_count": len(result.conflicts),
        }
        return result

    @staticmethod
    def to_generic_intent(selected_action: Dict[str, Any]) -> GenericIntent:
        if not selected_action.get("eligible_for_binding", False):
            raise MultiplexError("selected action is not eligible for host binding")
        return GenericIntent(
            intent=selected_action["intent"],
            target=selected_action["target"],
            magnitude=float(selected_action["magnitude"]),
            reason=selected_action.get("reason", ""),
            provenance=deepcopy(selected_action.get("provenance", {})),
        )
