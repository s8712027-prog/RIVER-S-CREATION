from __future__ import annotations
from pathlib import Path
import json
import sys

ROOT = Path(__file__).resolve().parent
PKG = ROOT.parent
sys.path.insert(0, str(ROOT))

from gcf_uma import (
    AdapterHostPlugin, BranchEnvelope, BranchMultiplexer, ContractRegistry,
    MockBranchTransport, MockTransactionalHost, SessionReplayGuard,
    TransactionCoordinator, UniversalAdapter,
)

contracts = ContractRegistry.from_directory(PKG / "15_BRANCH_CONTRACTS")
mux = BranchMultiplexer.from_yaml(contracts, PKG / "20_PROFILES/branch_multiplex_profile.yaml")
adapter = UniversalAdapter.from_yaml(PKG / "20_PROFILES/mock_energy_profile.yaml")
guard = SessionReplayGuard.from_yaml(PKG / "20_PROFILES/transaction_session_profile.yaml")
transport = MockBranchTransport()
host = MockTransactionalHost({"energy.request_sensor_refresh": "energy.cancel_sensor_refresh"})
coordinator = TransactionCoordinator.from_yaml(mux, AdapterHostPlugin(adapter), guard, host, PKG / "20_PROFILES/transaction_session_profile.yaml", transport=transport)

sessions = {"OBS-CoreV2":"obs-demo","AI-8":"ai-demo","BCRC-PGRC":"cert-demo"}
for branch, session in sessions.items():
    coordinator.open_session(branch, session)

now = 100.0

def env(mid, branch, contract, version, mtype, payload, seq, issued, session, priority=50):
    return BranchEnvelope(mid, branch, contract, version, mtype, payload, priority, {"demo":True}, session, seq, issued, None)

action = env("ai-1","AI-8","GCF_AI8_ACTION_ROUTER_CONTRACT","0.5d","ACTION_INTENT",{"intent":"PROTECT_CRITICAL","target":"load","magnitude":0.20,"reason":"demo route","confidence":0.9},1,now,sessions["AI-8"],80)
evidence = env("obs-1","OBS-CoreV2","GCF_OBS_COREV2_ADAPTER_CONTRACT","0.1k","EVIDENCE_STATUS",{"support_class":"SUPPORTED","uncertainty":0.1,"source_diversity":0.85},1,now,sessions["OBS-CoreV2"],90)
certificate = env("cert-1","BCRC-PGRC","GCF_BCRC_PGRC_CERTIFICATE_CONTRACT","1.0","CERTIFICATE_STATUS",{"certificate_id":"demo-cert","state":"VALID","scope":"load","reason":"demo"},1,now,sessions["BCRC-PGRC"],95)

transport.set_online("OBS-CoreV2", False)
transport.set_online("BCRC-PGRC", False)
record = coordinator.begin("tx-physical", [action, evidence, certificate], now)
initial_state = record.state

transport.set_online("OBS-CoreV2", True)
transport.set_online("BCRC-PGRC", True)
recovered = coordinator.supplement("tx-physical", [
    BranchEnvelope(**{**evidence.__dict__, "message_id":"obs-2", "sequence":2, "issued_at":now+0.5}),
    BranchEnvelope(**{**certificate.__dict__, "message_id":"cert-2", "sequence":2, "issued_at":now+0.5}),
], now+0.5)
recovered_state = recovered.state
commit = coordinator.commit("tx-physical", now+0.6, approval=True)
idempotent = coordinator.commit("tx-physical", now+0.7, approval=True)

observation_action = env("ai-2","AI-8","GCF_AI8_ACTION_ROUTER_CONTRACT","0.5d","ACTION_INTENT",{"intent":"REQUEST_OBSERVATION","target":"telemetry","magnitude":1.0,"reason":"refresh","confidence":0.8},2,now+1.0,sessions["AI-8"],80)
obs_tx = coordinator.begin("tx-observation", [observation_action], now+1.0)
obs_prepared_state = obs_tx.state
obs_commit = coordinator.commit("tx-observation", now+1.1)
obs_rollback = coordinator.rollback("tx-observation", now+1.2)

output = {
    "version":"GCF-UMA-v0.1b",
    "physical_transaction": {
        "initial_state":initial_state,
        "recovered_state":recovered_state,
        "commit":commit,
        "idempotent_commit":idempotent,
    },
    "reversible_observation_transaction": {
        "prepared_state":obs_prepared_state,
        "commit":obs_commit,
        "rollback":obs_rollback,
    },
    "host_execution_count":len(host.executions),
    "receipt_chain_valid":coordinator.verify_receipt_chain(),
}
print(json.dumps(output, indent=2))
