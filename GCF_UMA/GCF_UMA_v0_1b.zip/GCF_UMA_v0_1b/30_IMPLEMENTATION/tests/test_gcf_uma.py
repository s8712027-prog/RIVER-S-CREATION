from pathlib import Path
import unittest
import sys

IMPL = Path(__file__).resolve().parents[1]
PKG = IMPL.parent
sys.path.insert(0, str(IMPL))
from gcf_uma import UniversalAdapter, AdapterError
from gcf_uma.models import GenericIntent

PROFILES = PKG / "20_PROFILES"

class TestUMA(unittest.TestCase):
    def energy(self):
        return UniversalAdapter.from_yaml(PROFILES / "mock_energy_profile.yaml")

    def sixg(self):
        return UniversalAdapter.from_yaml(PROFILES / "mock_6g_profile.yaml")

    def energy_payload(self):
        return {
            "timestamp": 10.0,
            "entities": ["source", "cooling", "critical_load"],
            "thermal_margin_pct": 35.0,
            "electrical_headroom_kw": 500.0,
            "coolant_temp_c": 72.0,
            "critical_load_kw": 250.0,
            "provenance": {"source_system": "mock_energy_lab", "source_identity": "sensor_bus_A"},
        }

    def sixg_payload(self):
        return {
            "timestamp": 10.0,
            "entities": ["cell", "scheduler", "urllc_slice"],
            "prb_headroom_pct": 40.0,
            "compute_headroom_gops": 300.0,
            "sinr_db": 18.0,
            "urllc_load_pct": 55.0,
            "provenance": {"source_system": "mock_ran", "source_identity": "ric_feed_A"},
        }

    def test_schema_and_units_energy(self):
        g = self.energy().to_generic(self.energy_payload())
        self.assertAlmostEqual(g["resources"]["thermal_reserve"], 0.35)
        self.assertAlmostEqual(g["resources"]["electrical_reserve"], 0.5)

    def test_schema_and_units_6g(self):
        g = self.sixg().to_generic(self.sixg_payload())
        self.assertAlmostEqual(g["resources"]["spectrum_reserve"], 0.40)
        self.assertAlmostEqual(g["resources"]["compute_reserve"], 0.3)

    def test_provenance_preserved(self):
        p = self.energy_payload()
        g = self.energy().to_generic(p)
        self.assertEqual(g["provenance"]["source_identity"], "sensor_bus_A")
        self.assertEqual(g["provenance"]["adapter_profile_id"], "MOCK_ENERGY_V0_1")
        self.assertEqual(len(g["provenance"]["transformations"]), 4)

    def test_missing_profile_field_rejected(self):
        p = self.energy_payload(); del p["thermal_margin_pct"]
        with self.assertRaises(AdapterError): self.energy().to_generic(p)

    def test_capability_enforcement(self):
        with self.assertRaises(AdapterError):
            self.sixg().bind_intent(GenericIntent("ENTER_DEGRADED_MODE", "cell", 0.2))

    def test_authority_enforcement(self):
        out = self.sixg().bind_intent(GenericIntent("ADJUST_ALLOCATION", "cell", 0.1))
        self.assertFalse(out.executable)
        self.assertTrue(out.approval_required)

    def test_auto_observation_request(self):
        out = self.energy().bind_intent(GenericIntent("REQUEST_OBSERVATION", "cooling", 1.0))
        self.assertTrue(out.executable)
        self.assertFalse(out.approval_required)

    def test_range_and_ramp_enforcement(self):
        a = self.energy()
        out1 = a.bind_intent(GenericIntent("PROTECT_CRITICAL", "load", 0.9))
        out2 = a.bind_intent(GenericIntent("PROTECT_CRITICAL", "load", 0.9))
        self.assertAlmostEqual(out1.magnitude, 0.10)
        self.assertAlmostEqual(out2.magnitude, 0.20)

    def test_cross_domain_isolation(self):
        e = self.energy().to_generic(self.energy_payload())
        r = self.sixg().to_generic(self.sixg_payload())
        self.assertNotEqual(e["domain_id"], r["domain_id"])
        self.assertIn("thermal_reserve", e["resources"])
        self.assertNotIn("thermal_reserve", r["resources"])

    def test_no_branch_logic_leakage(self):
        a = self.energy()
        p = self.energy_payload()
        p["coolant_temp_c"] = 999.0
        g = a.to_generic(p)
        self.assertEqual(g["observations"]["coolant_temperature"], 999.0)
        # Adapter translates; it does not infer risk, block, or select action.
        self.assertNotIn("risk", g)
        self.assertNotIn("intent", g)

if __name__ == "__main__":
    unittest.main()
