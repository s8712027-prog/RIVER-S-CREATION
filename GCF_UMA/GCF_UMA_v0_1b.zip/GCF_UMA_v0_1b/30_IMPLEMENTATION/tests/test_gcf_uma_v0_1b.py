from pathlib import Path
import sys
import unittest

IMPL = Path(__file__).resolve().parents[1]
PKG = IMPL.parent
sys.path.insert(0, str(IMPL))

from gcf_uma import (
    AdapterHostPlugin,
    BranchEnvelope,
    BranchMultiplexer,
    ContractRegistry,
    MockBranchTransport,
    MockTransactionalHost,
    SessionReplayGuard,
    TransactionCoordinator,
    TransactionError,
    UniversalAdapter,
)

CONTRACTS = PKG / "15_BRANCH_CONTRACTS"
PROFILES = PKG / "20_PROFILES"


class TestUMAV01B(unittest.TestCase):
    def setUp(self):
        registry = ContractRegistry.from_directory(CONTRACTS)
        mux = BranchMultiplexer.from_yaml(registry, PROFILES / "branch_multiplex_profile.yaml")
        self.adapter = UniversalAdapter.from_yaml(PROFILES / "mock_energy_profile.yaml")
        plugin = AdapterHostPlugin(self.adapter)
        self.guard = SessionReplayGuard.from_yaml(PROFILES / "transaction_session_profile.yaml")
        self.transport = MockBranchTransport()
        self.host = MockTransactionalHost({
            "energy.request_sensor_refresh": "energy.cancel_sensor_refresh",
        })
        self.tx = TransactionCoordinator.from_yaml(
            mux, plugin, self.guard, self.host,
            PROFILES / "transaction_session_profile.yaml",
            transport=self.transport,
        )
        for branch, session in (("OBS-CoreV2", "obs-s1"), ("AI-8", "ai-s1"), ("BH", "bh-s1"), ("BCRC-PGRC", "cert-s1")):
            self.tx.open_session(branch, session)
        self.now = 100.0

    def env(self, branch, msg_id, msg_type, payload, seq, issued=None, expires=None, session=None):
        defaults = {
            "OBS-CoreV2": ("GCF_OBS_COREV2_ADAPTER_CONTRACT", "0.1k", "obs-s1"),
            "AI-8": ("GCF_AI8_ACTION_ROUTER_CONTRACT", "0.5d", "ai-s1"),
            "BH": ("GCF_BH_TOPOLOGY_MARGIN_CONTRACT", "PROV8A-v1.1", "bh-s1"),
            "BCRC-PGRC": ("GCF_BCRC_PGRC_CERTIFICATE_CONTRACT", "1.0", "cert-s1"),
        }
        contract, version, default_session = defaults[branch]
        return BranchEnvelope(
            msg_id, branch, contract, version, msg_type, payload, 50, {"test": self._testMethodName},
            session or default_session, seq, self.now if issued is None else issued, expires,
        )

    def evidence(self, seq=1, issued=None, expires=None, support="SUPPORTED"):
        return self.env("OBS-CoreV2", f"e{seq}", "EVIDENCE_STATUS", {"support_class": support, "uncertainty": 0.1, "source_diversity": 0.8}, seq, issued, expires)

    def cert(self, seq=1, issued=None, expires=None, state="VALID", scope="load"):
        return self.env("BCRC-PGRC", f"c{seq}", "CERTIFICATE_STATUS", {"certificate_id": f"c{seq}", "state": state, "scope": scope, "reason": "test"}, seq, issued, expires)

    def action(self, seq=1, intent="PROTECT_CRITICAL", target="load", magnitude=0.2, issued=None):
        return self.env("AI-8", f"a{seq}", "ACTION_INTENT", {"intent": intent, "target": target, "magnitude": magnitude, "reason": "route", "confidence": 0.9}, seq, issued)

    def test_missing_session_rejected(self):
        bad = self.action(1)
        bad = BranchEnvelope(bad.message_id, bad.branch_id, bad.contract_id, bad.contract_version, bad.message_type, bad.payload, bad.priority, bad.provenance, "", 1, self.now, None)
        rec = self.tx.begin("t1", [bad], self.now)
        self.assertEqual(rec.state, "ABORTED")
        self.assertEqual(rec.transport_rejections[0]["reason"], "MISSING_SESSION_ID")

    def test_replay_and_duplicate_rejected(self):
        first = self.action(1, intent="REQUEST_OBSERVATION", target="telemetry", magnitude=1.0)
        rec1 = self.tx.begin("t1", [first], self.now)
        self.assertEqual(rec1.state, "PREPARED")
        rec2 = self.tx.begin("t2", [first], self.now + 0.1)
        self.assertEqual(rec2.transport_rejections[0]["reason"], "DUPLICATE_MESSAGE")
        older = self.env("AI-8", "different-id", "ACTION_INTENT", first.payload, 1, issued=self.now + 0.1)
        rec3 = self.tx.begin("t3", [older], self.now + 0.1)
        self.assertEqual(rec3.transport_rejections[0]["reason"], "REPLAY_OR_OUT_OF_ORDER")

    def test_sequence_gap_is_allowed_but_old_sequence_is_not(self):
        rec = self.tx.begin("t1", [self.action(3, intent="REQUEST_OBSERVATION", target="telemetry", magnitude=1.0)], self.now)
        self.assertEqual(rec.state, "PREPARED")
        old = self.env("AI-8", "a2-late", "ACTION_INTENT", {"intent":"REQUEST_OBSERVATION","target":"telemetry","magnitude":1.0,"reason":"x","confidence":0.8}, 2, issued=self.now + 0.1)
        rec2 = self.tx.begin("t2", [old], self.now + 0.1)
        self.assertEqual(rec2.transport_rejections[0]["reason"], "REPLAY_OR_OUT_OF_ORDER")

    def test_stale_evidence_and_certificate_block_physical_action(self):
        rec = self.tx.begin("t1", [self.evidence(1, issued=90.0), self.cert(1, issued=90.0), self.action(1)], self.now)
        reasons = {x["reason"] for x in rec.transport_rejections}
        self.assertIn("STALE_MESSAGE", reasons)
        self.assertEqual(rec.state, "PENDING_INPUT")
        self.assertEqual(len(self.host.executions), 0)

    def test_prepare_is_side_effect_free(self):
        rec = self.tx.begin("t1", [self.action(1, intent="REQUEST_OBSERVATION", target="telemetry", magnitude=1.0)], self.now)
        self.assertEqual(rec.state, "PREPARED")
        self.assertEqual(self.adapter.export_state(), {})
        self.tx.commit("t1", self.now + 0.1)
        self.assertEqual(self.adapter.export_state()["REQUEST_OBSERVATION"], 1.0)

    def test_idempotent_commit_executes_once(self):
        self.tx.begin("t1", [self.action(1, intent="REQUEST_OBSERVATION", target="telemetry", magnitude=1.0)], self.now)
        r1 = self.tx.commit("t1", self.now + 0.1)
        r2 = self.tx.commit("t1", self.now + 0.2)
        self.assertEqual(len(self.host.executions), 1)
        self.assertFalse(r1["idempotent_replay"])
        self.assertTrue(r2["idempotent_replay"])
        self.assertEqual(r1["receipt_hash"], r2["receipt_hash"])

    def test_approval_lifecycle(self):
        rec = self.tx.begin("t1", [self.evidence(), self.cert(), self.action()], self.now)
        self.assertEqual(rec.state, "PENDING_APPROVAL")
        with self.assertRaises(TransactionError):
            self.tx.commit("t1", self.now + 0.1)
        receipt = self.tx.commit("t1", self.now + 0.2, approval=True)
        self.assertEqual(receipt["state"], "COMMITTED")
        self.assertEqual(len(self.host.executions), 1)

    def test_abort_has_no_execution(self):
        self.tx.begin("t1", [self.action(1, intent="REQUEST_OBSERVATION", target="telemetry", magnitude=1.0)], self.now)
        receipt = self.tx.abort("t1", self.now + 0.1, "operator_cancel")
        self.assertEqual(receipt["state"], "ABORTED")
        self.assertEqual(len(self.host.executions), 0)

    def test_timeout_has_no_execution(self):
        rec = self.tx.begin("t1", [self.evidence(), self.cert(), self.action()], self.now, timeout=1.0)
        self.assertEqual(rec.state, "PENDING_APPROVAL")
        expired = self.tx.expire_pending(self.now + 2.0)
        self.assertEqual(expired, ["t1"])
        self.assertEqual(self.tx.transactions["t1"].state, "TIMED_OUT")
        self.assertEqual(len(self.host.executions), 0)

    def test_partial_outage_allows_observation_request_but_blocks_physical_action(self):
        self.transport.set_online("OBS-CoreV2", False)
        self.transport.set_online("BCRC-PGRC", False)
        req = self.tx.begin("t1", [self.evidence(), self.cert(), self.action(1, intent="REQUEST_OBSERVATION", target="telemetry", magnitude=1.0)], self.now)
        self.assertEqual(req.state, "PREPARED")
        self.tx.commit("t1", self.now + 0.1)
        self.assertEqual(len(self.host.executions), 1)
        # New sessions/sequences for a separate physical request.
        self.tx.open_session("AI-8", "ai-s2")
        physical = self.env("AI-8", "a-new", "ACTION_INTENT", {"intent":"PROTECT_CRITICAL","target":"load","magnitude":0.2,"reason":"x","confidence":0.9}, 1, issued=self.now + 0.2, session="ai-s2")
        blocked = self.tx.begin("t2", [physical], self.now + 0.2)
        self.assertEqual(blocked.state, "PENDING_INPUT")

    def test_session_rollover_rejects_retired_session(self):
        self.tx.open_session("AI-8", "ai-s2")
        old = self.action(1, intent="REQUEST_OBSERVATION", target="telemetry", magnitude=1.0)
        rec = self.tx.begin("t1", [old], self.now)
        self.assertEqual(rec.transport_rejections[0]["reason"], "RETIRED_SESSION")
        fresh = self.env("AI-8", "fresh", "ACTION_INTENT", old.payload, 1, issued=self.now, session="ai-s2")
        rec2 = self.tx.begin("t2", [fresh], self.now)
        self.assertEqual(rec2.state, "PREPARED")
        with self.assertRaises(TransactionError):
            self.tx.open_session("AI-8", "ai-s1")

    def test_rollback_is_explicit_and_idempotent(self):
        self.tx.begin("t1", [self.action(1, intent="REQUEST_OBSERVATION", target="telemetry", magnitude=1.0)], self.now)
        self.tx.commit("t1", self.now + 0.1)
        r1 = self.tx.rollback("t1", self.now + 0.2)
        r2 = self.tx.rollback("t1", self.now + 0.3)
        self.assertEqual(r1["state"], "ROLLED_BACK")
        self.assertTrue(r2["idempotent_replay"])
        self.assertEqual(len(self.host.executions), 1)
        execution = next(iter(self.host.executions.values()))
        self.assertEqual(execution["state"], "ROLLED_BACK")

    def test_receipt_chain_detects_tampering(self):
        self.tx.begin("t1", [self.action(1, intent="REQUEST_OBSERVATION", target="telemetry", magnitude=1.0)], self.now)
        self.tx.commit("t1", self.now + 0.1)
        self.tx.begin("t2", [self.env("AI-8", "a2", "ACTION_INTENT", {"intent":"REQUEST_OBSERVATION","target":"other","magnitude":1.0,"reason":"x","confidence":0.9}, 2, issued=self.now+0.2)], self.now + 0.2)
        self.tx.abort("t2", self.now + 0.3, "test")
        self.assertTrue(self.tx.verify_receipt_chain())
        self.tx.receipt_chain[0]["state"] = "FORGED"
        self.assertFalse(self.tx.verify_receipt_chain())

    def test_explicit_expiry_rejected(self):
        expired = self.action(1, intent="REQUEST_OBSERVATION", target="telemetry", magnitude=1.0)
        expired = BranchEnvelope(expired.message_id, expired.branch_id, expired.contract_id, expired.contract_version, expired.message_type, expired.payload, expired.priority, expired.provenance, expired.session_id, expired.sequence, expired.issued_at, self.now - 0.1)
        rec = self.tx.begin("t1", [expired], self.now)
        self.assertEqual(rec.transport_rejections[0]["reason"], "EXPIRED_MESSAGE")

    def test_pending_input_can_recover_by_supplement(self):
        self.transport.set_online("OBS-CoreV2", False)
        self.transport.set_online("BCRC-PGRC", False)
        rec = self.tx.begin("t1", [self.evidence(), self.cert(), self.action()], self.now)
        self.assertEqual(rec.state, "PENDING_INPUT")
        self.transport.set_online("OBS-CoreV2", True)
        self.transport.set_online("BCRC-PGRC", True)
        recovered = self.tx.supplement("t1", [self.evidence(2, issued=self.now+0.5), self.cert(2, issued=self.now+0.5)], self.now+0.5)
        self.assertEqual(recovered.state, "PENDING_APPROVAL")
        receipt = self.tx.commit("t1", self.now+0.6, approval=True)
        self.assertEqual(receipt["state"], "COMMITTED")

    def test_input_freshness_caps_transaction_deadline(self):
        rec = self.tx.begin("t1", [self.evidence(), self.cert(), self.action()], self.now, timeout=20.0)
        self.assertEqual(rec.deadline, self.now + 3.0)
        receipt = self.tx.commit("t1", self.now+3.1, approval=True)
        self.assertEqual(receipt["state"], "TIMED_OUT")
        self.assertEqual(len(self.host.executions), 0)


if __name__ == "__main__":
    unittest.main()
