from pathlib import Path
import sys
import unittest

IMPL = Path(__file__).resolve().parents[1]
PKG = IMPL.parent
sys.path.insert(0, str(IMPL))

from gcf_uma import AdapterHostPlugin, BranchEnvelope, BranchMultiplexer, ContractRegistry, MultiplexError, UniversalAdapter

CONTRACTS = PKG / "15_BRANCH_CONTRACTS"
PROFILES = PKG / "20_PROFILES"

class TestUMAV01A(unittest.TestCase):
    def setUp(self):
        self.registry = ContractRegistry.from_directory(CONTRACTS)
        self.mux = BranchMultiplexer.from_yaml(self.registry, PROFILES / "branch_multiplex_profile.yaml")

    def env(self, branch, msg_id, msg_type, payload, version=None, priority=50, contract=None):
        defaults = {
            "OBS-CoreV2": ("GCF_OBS_COREV2_ADAPTER_CONTRACT", "0.1k"),
            "AI-8": ("GCF_AI8_ACTION_ROUTER_CONTRACT", "0.5d"),
            "BH": ("GCF_BH_TOPOLOGY_MARGIN_CONTRACT", "PROV8A-v1.1"),
            "BCRC-PGRC": ("GCF_BCRC_PGRC_CERTIFICATE_CONTRACT", "1.0"),
        }
        c, v = defaults.get(branch, ("UNKNOWN", "0"))
        return BranchEnvelope(msg_id, branch, contract or c, version or v, msg_type, payload, priority, {"test": self._testMethodName})

    def evidence(self, support="SUPPORTED"):
        return self.env("OBS-CoreV2", "e1", "EVIDENCE_STATUS", {"support_class":support,"uncertainty":0.1,"source_diversity":0.8}, priority=90)

    def cert(self, state="VALID", scope="load"):
        return self.env("BCRC-PGRC", "c1", "CERTIFICATE_STATUS", {"certificate_id":"c","state":state,"scope":scope,"reason":"test"}, priority=95)

    def ai_action(self, intent="PROTECT_CRITICAL", target="load", magnitude=0.2, msg_id="a1"):
        return self.env("AI-8", msg_id, "ACTION_INTENT", {"intent":intent,"target":target,"magnitude":magnitude,"reason":"route","confidence":0.9}, priority=80)

    def obs_action(self, intent="PROTECT_CRITICAL", target="load", magnitude=0.1, msg_id="o1"):
        return self.env("OBS-CoreV2", msg_id, "BOUNDED_RESCUE_INTENT", {"intent":intent,"target":target,"magnitude":magnitude,"reason":"obs bounded"}, priority=70)

    def test_negotiation_selects_highest_exact_common(self):
        r = self.registry.negotiate("AI-8", "GCF_AI8_ACTION_ROUTER_CONTRACT", ["0.5c", "0.5d", "0.6-candidate"])
        self.assertEqual(r.state, "NEGOTIATED")
        self.assertEqual(r.selected_version, "0.6-candidate")

    def test_no_common_version_rejected(self):
        r = self.registry.negotiate("OBS-CoreV2", "GCF_OBS_COREV2_ADAPTER_CONTRACT", ["0.1i"])
        self.assertEqual(r.state, "NO_COMMON_VERSION")

    def test_unknown_branch_isolated(self):
        bad = self.env("UNKNOWN", "x", "ACTION_INTENT", {"intent":"HOLD"})
        result = self.mux.process([bad, self.evidence()])
        self.assertEqual(result.accepted_message_ids, ["e1"])
        self.assertEqual(len(result.rejected_messages), 1)

    def test_bh_cannot_inject_action(self):
        bad = self.env("BH", "bhx", "ACTION_INTENT", {"intent":"PROTECT_CRITICAL","target":"load","magnitude":1.0})
        result = self.mux.process([bad])
        self.assertEqual(result.status, "REJECTED")
        self.assertEqual(len(result.action_candidates), 0)

    def test_obs_policy_advisory_not_host_action(self):
        result = self.mux.process([self.evidence(), self.cert(), self.obs_action(magnitude=0.12), self.ai_action(magnitude=0.18)])
        self.assertEqual(len(result.policy_advisories), 1)
        self.assertEqual(len(result.action_candidates), 1)
        action = result.selected_actions[0]
        self.assertEqual(action["source_branches"], ["AI-8"])
        self.assertTrue(action["eligible_for_binding"])

    def test_exact_duplicate_ai8_intents_deduplicate(self):
        result = self.mux.process([self.evidence(), self.cert(), self.ai_action(magnitude=0.18, msg_id="a1"), self.ai_action(magnitude=0.18, msg_id="a2")])
        self.assertEqual(len(result.selected_actions), 1)
        self.assertEqual(result.selected_actions[0]["source_message_ids"], ["a1", "a2"])

    def test_same_intent_different_magnitude_conflicts(self):
        result = self.mux.process([self.evidence(), self.cert(), self.ai_action(magnitude=0.12, msg_id="a1"), self.ai_action(magnitude=0.18, msg_id="a2")])
        self.assertEqual(len(result.conflicts), 1)
        self.assertEqual(len(result.selected_actions), 0)

    def test_ambiguous_intents_block_target(self):
        result = self.mux.process([self.evidence(), self.cert(), self.ai_action(intent="HOLD", msg_id="a1"), self.ai_action(intent="PROTECT_CRITICAL", msg_id="a2")])
        self.assertEqual(len(result.conflicts), 1)
        self.assertEqual(len(result.selected_actions), 0)
        self.assertEqual(result.status, "PARTIAL")

    def test_invalid_certificate_blocks_binding(self):
        result = self.mux.process([self.evidence(), self.cert("INVALID"), self.ai_action()])
        self.assertFalse(result.selected_actions[0]["eligible_for_binding"])
        self.assertIn("certificate=INVALID not allowed", result.selected_actions[0]["ineligibility_reasons"])

    def test_unsupported_evidence_blocks_physical_action(self):
        result = self.mux.process([self.evidence("UNSUPPORTED"), self.cert(), self.ai_action()])
        self.assertFalse(result.selected_actions[0]["eligible_for_binding"])

    def test_request_observation_allowed_under_unsupported(self):
        action = self.ai_action(intent="REQUEST_OBSERVATION", target="telemetry", magnitude=1.0)
        result = self.mux.process([self.evidence("UNSUPPORTED"), action])
        self.assertTrue(result.selected_actions[0]["eligible_for_binding"])

    def test_provenance_namespaced(self):
        result = self.mux.process([self.evidence()])
        self.assertEqual(result.evidence[0]["provenance"]["adapter_branch_namespace"], "OBS-CoreV2")

    def test_priority_order_is_deterministic(self):
        low = self.env("OBS-CoreV2", "low", "OBSERVATION_REQUEST", {"target":"x","priority":1,"expected_information_value":0.2}, priority=10)
        high = self.env("OBS-CoreV2", "high", "OBSERVATION_REQUEST", {"target":"y","priority":9,"expected_information_value":0.8}, priority=90)
        result = self.mux.process([low, high])
        self.assertEqual([x["message_id"] for x in result.observation_requests], ["high", "low"])

    def test_host_authority_preserved(self):
        result = self.mux.process([self.evidence(), self.cert(), self.ai_action(intent="ADJUST_ALLOCATION", target="load", magnitude=0.1)])
        energy = UniversalAdapter.from_yaml(PROFILES / "mock_energy_profile.yaml")
        bound = AdapterHostPlugin(energy).bind(result)
        self.assertEqual(bound["bound"][0]["authority_mode"], "APPROVAL_REQUIRED")
        self.assertFalse(bound["bound"][0]["executable"])

    def test_cross_domain_host_binding_isolated(self):
        result = self.mux.process([self.evidence(), self.ai_action(intent="REQUEST_OBSERVATION", target="state", magnitude=1.0)])
        energy = AdapterHostPlugin(UniversalAdapter.from_yaml(PROFILES / "mock_energy_profile.yaml")).bind(result)
        sixg = AdapterHostPlugin(UniversalAdapter.from_yaml(PROFILES / "mock_6g_profile.yaml")).bind(result)
        self.assertEqual(energy["bound"][0]["host_operation"], "energy.request_sensor_refresh")
        self.assertEqual(sixg["bound"][0]["host_operation"], "ran.request_measurement_report")

    def test_semantic_loss_sidecar_preserves_reason_confidence(self):
        result = self.mux.process([self.evidence(), self.cert(), self.ai_action()])
        bound = AdapterHostPlugin(UniversalAdapter.from_yaml(PROFILES / "mock_energy_profile.yaml")).bind(result)
        sidecar = bound["bound"][0]["audit_sidecar"]
        self.assertEqual(sidecar["reason"], "route")
        self.assertEqual(sidecar["confidence"], 0.9)
        self.assertEqual(bound["semantic_loss_ledger"][0]["loss_class"], "AUDIT_SIDECAR_ONLY")

    def test_invalid_payload_does_not_drop_valid_messages(self):
        bad = self.env("AI-8", "bad", "ACTION_INTENT", {"intent":"HOLD"})
        result = self.mux.process([self.evidence(), bad])
        self.assertEqual(len(result.evidence), 1)
        self.assertEqual(len(result.rejected_messages), 1)

    def test_annotation_does_not_create_action(self):
        bh = self.env("BH", "bh1", "TOPOLOGY_MARGIN", {"boundary_proximity":0.99,"margin_remaining":0.01,"transition_risk":0.99,"provenance_class":"REDUCED_ORDER_BH_PRIOR","confidence":0.9})
        result = self.mux.process([bh])
        self.assertEqual(len(result.annotations), 1)
        self.assertEqual(len(result.action_candidates), 0)
        self.assertEqual(len(result.selected_actions), 0)

    def test_host_plugin_skips_ineligible_action(self):
        result = self.mux.process([self.evidence("UNSUPPORTED"), self.cert(), self.ai_action()])
        bound = AdapterHostPlugin(UniversalAdapter.from_yaml(PROFILES / "mock_energy_profile.yaml")).bind(result)
        self.assertEqual(len(bound["bound"]), 0)
        self.assertEqual(len(bound["skipped"]), 1)

    def test_observation_request_route_separate_from_action(self):
        req = self.env("OBS-CoreV2", "q1", "OBSERVATION_REQUEST", {"target":"thermal","priority":8,"expected_information_value":0.7}, priority=70)
        result = self.mux.process([req])
        self.assertEqual(len(result.observation_requests), 1)
        self.assertEqual(len(result.action_candidates), 0)

if __name__ == "__main__":
    unittest.main()
