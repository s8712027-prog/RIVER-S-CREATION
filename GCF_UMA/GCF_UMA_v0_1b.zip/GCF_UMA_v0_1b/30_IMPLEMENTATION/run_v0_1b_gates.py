from __future__ import annotations
from pathlib import Path
import json
import sys

ROOT = Path(__file__).resolve().parent
PKG = ROOT.parent
sys.path.insert(0, str(ROOT))

from gcf_uma import (
    AdapterHostPlugin, BranchEnvelope, BranchMultiplexer, ContractRegistry,
    MockBranchTransport, MockTransactionalHost, SessionReplayGuard,
    TransactionCoordinator, TransactionError, UniversalAdapter,
)

CONTRACTS = PKG / "15_BRANCH_CONTRACTS"
PROFILES = PKG / "20_PROFILES"
NOW = 100.0


def make_system():
    registry = ContractRegistry.from_directory(CONTRACTS)
    mux = BranchMultiplexer.from_yaml(registry, PROFILES / "branch_multiplex_profile.yaml")
    adapter = UniversalAdapter.from_yaml(PROFILES / "mock_energy_profile.yaml")
    guard = SessionReplayGuard.from_yaml(PROFILES / "transaction_session_profile.yaml")
    transport = MockBranchTransport()
    host = MockTransactionalHost({"energy.request_sensor_refresh": "energy.cancel_sensor_refresh"})
    tx = TransactionCoordinator.from_yaml(mux, AdapterHostPlugin(adapter), guard, host, PROFILES / "transaction_session_profile.yaml", transport=transport)
    sessions = {"OBS-CoreV2":"obs-s1","AI-8":"ai-s1","BH":"bh-s1","BCRC-PGRC":"cert-s1"}
    for branch, session in sessions.items():
        tx.open_session(branch, session)
    return tx, adapter, host, transport, sessions


def env(branch, msg_id, msg_type, payload, seq, session, issued=NOW, expires=None, priority=50):
    specs = {
        "OBS-CoreV2": ("GCF_OBS_COREV2_ADAPTER_CONTRACT", "0.1k"),
        "AI-8": ("GCF_AI8_ACTION_ROUTER_CONTRACT", "0.5d"),
        "BH": ("GCF_BH_TOPOLOGY_MARGIN_CONTRACT", "PROV8A-v1.1"),
        "BCRC-PGRC": ("GCF_BCRC_PGRC_CERTIFICATE_CONTRACT", "1.0"),
    }
    contract, version = specs[branch]
    return BranchEnvelope(msg_id, branch, contract, version, msg_type, payload, priority, {"formal_gate":True}, session, seq, issued, expires)


def evidence(seq=1, issued=NOW, expires=None, support="SUPPORTED", session="obs-s1"):
    return env("OBS-CoreV2", f"e{seq}", "EVIDENCE_STATUS", {"support_class":support,"uncertainty":0.1,"source_diversity":0.8}, seq, session, issued, expires, 90)


def cert(seq=1, issued=NOW, expires=None, state="VALID", session="cert-s1"):
    return env("BCRC-PGRC", f"c{seq}", "CERTIFICATE_STATUS", {"certificate_id":f"c{seq}","state":state,"scope":"load","reason":"formal"}, seq, session, issued, expires, 95)


def action(seq=1, intent="PROTECT_CRITICAL", target="load", magnitude=0.2, issued=NOW, session="ai-s1", msg_id=None):
    return env("AI-8", msg_id or f"a{seq}", "ACTION_INTENT", {"intent":intent,"target":target,"magnitude":magnitude,"reason":"formal","confidence":0.9}, seq, session, issued, None, 80)


results = {}

# T1 session identity required.
tx, adapter, host, transport, sessions = make_system()
bad = action(intent="REQUEST_OBSERVATION", target="telemetry", magnitude=1.0)
bad = BranchEnvelope(bad.message_id,bad.branch_id,bad.contract_id,bad.contract_version,bad.message_type,bad.payload,bad.priority,bad.provenance,"",1,NOW,None)
r = tx.begin("t1", [bad], NOW)
results["T1"] = {"pass": r.state == "ABORTED" and r.transport_rejections[0]["reason"] == "MISSING_SESSION_ID", "detail": r.to_dict()}

# T2 duplicate and replay protection.
tx, adapter, host, transport, sessions = make_system()
msg = action(intent="REQUEST_OBSERVATION", target="telemetry", magnitude=1.0)
r1 = tx.begin("t1", [msg], NOW)
r2 = tx.begin("t2", [msg], NOW+0.1)
old = action(seq=1,intent="REQUEST_OBSERVATION",target="telemetry",magnitude=1.0,issued=NOW+0.1,msg_id="new-id")
r3 = tx.begin("t3", [old], NOW+0.1)
results["T2"] = {"pass": r1.state == "PREPARED" and r2.transport_rejections[0]["reason"] == "DUPLICATE_MESSAGE" and r3.transport_rejections[0]["reason"] == "REPLAY_OR_OUT_OF_ORDER", "detail": {"first":r1.to_dict(),"duplicate":r2.to_dict(),"replay":r3.to_dict()}}

# T3 session rollover.
tx, adapter, host, transport, sessions = make_system()
tx.open_session("AI-8", "ai-s2")
old = action(intent="REQUEST_OBSERVATION",target="telemetry",magnitude=1.0)
rold = tx.begin("old", [old], NOW)
fresh = action(intent="REQUEST_OBSERVATION",target="telemetry",magnitude=1.0,session="ai-s2",msg_id="fresh")
rnew = tx.begin("new", [fresh], NOW)
reopen_blocked = False
try:
    tx.open_session("AI-8", "ai-s1")
except TransactionError:
    reopen_blocked = True
results["T3"] = {"pass": rold.transport_rejections[0]["reason"] == "RETIRED_SESSION" and rnew.state == "PREPARED" and reopen_blocked, "detail": {"old":rold.to_dict(),"new":rnew.to_dict(),"reopen_blocked":reopen_blocked}}

# T4 stale evidence/certificate expiry.
tx, adapter, host, transport, sessions = make_system()
r = tx.begin("t1", [evidence(issued=90.0), cert(issued=90.0), action()], NOW)
reasons = sorted(x["reason"] for x in r.transport_rejections)
results["T4"] = {"pass": reasons == ["STALE_MESSAGE","STALE_MESSAGE"] and r.state == "PENDING_INPUT" and len(host.executions)==0, "detail": r.to_dict()}

# T5 prepare side-effect free.
tx, adapter, host, transport, sessions = make_system()
r = tx.begin("t1", [action(intent="REQUEST_OBSERVATION",target="telemetry",magnitude=1.0)], NOW)
before = adapter.export_state()
receipt = tx.commit("t1", NOW+0.1)
after = adapter.export_state()
results["T5"] = {"pass": before == {} and after.get("REQUEST_OBSERVATION") == 1.0 and receipt["state"] == "COMMITTED", "detail": {"record":r.to_dict(),"before":before,"after":after,"receipt":receipt}}

# T6 approval lifecycle.
tx, adapter, host, transport, sessions = make_system()
r = tx.begin("t1", [evidence(), cert(), action()], NOW)
initial_state = r.state
blocked = False
try:
    tx.commit("t1", NOW+0.1)
except TransactionError:
    blocked = True
receipt = tx.commit("t1", NOW+0.2, approval=True)
results["T6"] = {"pass": initial_state == "PENDING_APPROVAL" and blocked and receipt["state"] == "COMMITTED" and len(host.executions)==1, "detail": {"record":r.to_dict(),"blocked_without_approval":blocked,"receipt":receipt}}

# T7 idempotent commit.
tx, adapter, host, transport, sessions = make_system()
tx.begin("t1", [action(intent="REQUEST_OBSERVATION",target="telemetry",magnitude=1.0)], NOW)
c1 = tx.commit("t1", NOW+0.1)
c2 = tx.commit("t1", NOW+0.2)
results["T7"] = {"pass": len(host.executions)==1 and not c1["idempotent_replay"] and c2["idempotent_replay"] and c1["receipt_hash"]==c2["receipt_hash"], "detail": {"first":c1,"second":c2,"execution_count":len(host.executions)}}

# T8 abort and timeout leave no host execution.
tx, adapter, host, transport, sessions = make_system()
tx.begin("abort", [action(intent="REQUEST_OBSERVATION",target="telemetry",magnitude=1.0)], NOW)
a = tx.abort("abort", NOW+0.1, "operator_cancel")
# Sequence 2 for next AI action and fresh other branches.
r = tx.begin("timeout", [evidence(), cert(), action(seq=2,issued=NOW+0.2,msg_id="a2")], NOW+0.2, timeout=0.5)
expired = tx.expire_pending(NOW+1.0)
results["T8"] = {"pass": a["state"]=="ABORTED" and r.state=="TIMED_OUT" and expired==["timeout"] and len(host.executions)==0, "detail": {"abort":a,"timeout":r.to_dict(),"expired":expired}}

# T9 partial branch outage: observation request allowed; physical action blocked.
tx, adapter, host, transport, sessions = make_system()
transport.set_online("OBS-CoreV2", False)
transport.set_online("BCRC-PGRC", False)
req = tx.begin("request", [evidence(), cert(), action(intent="REQUEST_OBSERVATION",target="telemetry",magnitude=1.0)], NOW)
req_receipt = tx.commit("request", NOW+0.1)
tx.open_session("AI-8", "ai-s2")
physical = action(intent="PROTECT_CRITICAL",session="ai-s2",msg_id="physical")
blocked = tx.begin("physical", [physical], NOW+0.2)
results["T9"] = {"pass": req_receipt["state"]=="COMMITTED" and blocked.state=="PENDING_INPUT" and len(host.executions)==1, "detail": {"request":req.to_dict(),"request_receipt":req_receipt,"physical":blocked.to_dict()}}

# T10 explicit rollback and idempotent rollback.
tx, adapter, host, transport, sessions = make_system()
tx.begin("t1", [action(intent="REQUEST_OBSERVATION",target="telemetry",magnitude=1.0)], NOW)
tx.commit("t1", NOW+0.1)
rb1 = tx.rollback("t1", NOW+0.2)
rb2 = tx.rollback("t1", NOW+0.3)
execution = next(iter(host.executions.values()))
results["T10"] = {"pass": rb1["state"]=="ROLLED_BACK" and rb2["idempotent_replay"] and execution["state"]=="ROLLED_BACK", "detail": {"first":rb1,"second":rb2,"execution":execution}}

# T11 receipt chain integrity.
tx, adapter, host, transport, sessions = make_system()
tx.begin("t1", [action(intent="REQUEST_OBSERVATION",target="telemetry",magnitude=1.0)], NOW)
tx.commit("t1", NOW+0.1)
chain_before = tx.verify_receipt_chain()
tx.receipt_chain[0]["state"] = "FORGED"
chain_after = tx.verify_receipt_chain()
results["T11"] = {"pass": chain_before and not chain_after, "detail": {"before_tamper":chain_before,"after_tamper":chain_after}}

# T12 explicit expiry.
tx, adapter, host, transport, sessions = make_system()
expired_msg = action(intent="REQUEST_OBSERVATION",target="telemetry",magnitude=1.0)
expired_msg = BranchEnvelope(expired_msg.message_id,expired_msg.branch_id,expired_msg.contract_id,expired_msg.contract_version,expired_msg.message_type,expired_msg.payload,expired_msg.priority,expired_msg.provenance,expired_msg.session_id,expired_msg.sequence,expired_msg.issued_at,NOW-0.1)
r = tx.begin("t1", [expired_msg], NOW)
results["T12"] = {"pass": r.transport_rejections[0]["reason"]=="EXPIRED_MESSAGE" and len(host.executions)==0, "detail": r.to_dict()}

# T13 invalid branch-role message remains isolated transactionally.
tx, adapter, host, transport, sessions = make_system()
bh_action = env("BH","bhx","ACTION_INTENT",{"intent":"PROTECT_CRITICAL","target":"load","magnitude":1.0},1,"bh-s1",NOW)
valid = action(intent="REQUEST_OBSERVATION",target="telemetry",magnitude=1.0)
r = tx.begin("t1", [bh_action, valid], NOW)
receipt = tx.commit("t1", NOW+0.1)
results["T13"] = {"pass": len(r.multiplex_result["rejected_messages"])==1 and receipt["state"]=="COMMITTED" and len(host.executions)==1, "detail": {"record":r.to_dict(),"receipt":receipt}}

# T14 prepare/commit preserves authority and capability/ramp behavior.
tx, adapter, host, transport, sessions = make_system()
r = tx.begin("t1", [evidence(),cert(),action(magnitude=0.9)], NOW)
preview = r.preview_binding["bound"][0]
receipt = tx.commit("t1", NOW+0.1, approval=True)
actual = receipt["binding"]["bound"][0]
results["T14"] = {"pass": preview["authority_mode"]=="APPROVAL_REQUIRED" and preview["magnitude"]==0.1 and actual["magnitude"]==0.1 and actual["approval_required"], "detail": {"preview":preview,"actual":actual}}

# T15 pending-input recovery through fresh supplement after branch restoration.
tx, adapter, host, transport, sessions = make_system()
transport.set_online("OBS-CoreV2", False)
transport.set_online("BCRC-PGRC", False)
pending = tx.begin("recover", [evidence(), cert(), action()], NOW)
initial_pending_state = pending.state
transport.set_online("OBS-CoreV2", True)
transport.set_online("BCRC-PGRC", True)
recovered = tx.supplement("recover", [evidence(seq=2,issued=NOW+0.5), cert(seq=2,issued=NOW+0.5)], NOW+0.5)
recovered_state = recovered.state
recovery_receipt = tx.commit("recover", NOW+0.6, approval=True)
results["T15"] = {"pass": initial_pending_state=="PENDING_INPUT" and recovered_state=="PENDING_APPROVAL" and recovery_receipt["state"]=="COMMITTED" and len(host.executions)==1, "detail": {"initial_state":initial_pending_state,"recovered_state":recovered_state,"record":recovered.to_dict(),"receipt":recovery_receipt}}

# T16 input freshness caps transaction deadline even if configured timeout is longer.
tx, adapter, host, transport, sessions = make_system()
rec = tx.begin("freshness", [evidence(),cert(),action()], NOW, timeout=20.0)
initial_deadline = rec.deadline
late_receipt = tx.commit("freshness", NOW+3.1, approval=True)
results["T16"] = {"pass": initial_deadline==NOW+3.0 and late_receipt["state"]=="TIMED_OUT" and len(host.executions)==0, "detail": {"initial_deadline":initial_deadline,"receipt":late_receipt}}

verdict = "PASS" if all(v["pass"] for v in results.values()) else "FAIL"
output = {
    "version":"GCF-UMA-v0.1b",
    "status":"TRANSACTIONAL_SESSION_REPLAY_PROTECTION_FAILURE_RECOVERY_PASS" if verdict=="PASS" else "TRANSACTIONAL_SESSION_REPLAY_PROTECTION_FAILURE_RECOVERY_FAIL",
    "verdict":verdict,
    "passed":sum(1 for v in results.values() if v["pass"]),
    "total":len(results),
    "gates":results,
}
print(json.dumps(output, indent=2))
