# Transactional Session Architecture — v0.1b

## Processing order

```text
Branch envelope
  → session identity
  → monotonic sequence / replay guard
  → issued-at / explicit expiry / max-age guard
  → branch contract and role validation
  → multiplex / conflict / eligibility evaluation
  → side-effect-free host preview
  → transaction state
  → explicit approval when required
  → idempotent commit
  → audit receipt
```

## State model

- `PENDING_INPUT`: action exists but current evidence/certificate or branch availability is insufficient.
- `PENDING_APPROVAL`: host profile requires explicit approval.
- `PENDING_AUTHORITY`: host profile allows translation but not execution through this transaction path.
- `PREPARED`: all declared conditions for automatic bounded execution are satisfied.
- `COMMITTED`: host operation executed exactly once under an idempotency key.
- `ABORTED`: transaction explicitly cancelled or structurally invalid.
- `TIMED_OUT`: transaction deadline or input-freshness deadline elapsed.
- `ROLLED_BACK`: a committed, declared-reversible mock operation was explicitly reversed.

## Freshness rule

The transaction deadline is capped by the earliest accepted input validity boundary:

```text
transaction_deadline = min(configured_timeout, evidence/action/certificate valid-until)
```

This prevents a once-valid action from being approved after its evidence or route has expired.

## Failure recovery

A `PENDING_INPUT` transaction may receive fresh supplementary branch envelopes. The full multiplex and eligibility path is rerun. Supplementation cannot bypass replay, session, contract, evidence, certificate, authority, or approval gates.

## Audit receipts

Receipts are SHA256 hash-chained to expose in-package tampering. This is an audit-integrity mechanism only; it is not digital signing, identity authentication, non-repudiation, or a production ledger.
