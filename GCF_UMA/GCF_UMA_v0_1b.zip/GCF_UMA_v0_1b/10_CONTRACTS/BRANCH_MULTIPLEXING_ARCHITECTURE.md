# Branch Multiplexing Architecture

```text
OBS-CoreV2 ── evidence / query / policy advisory ─┐
AI-8 ───────────── final action intent ───────────┼→ GCF-UMA Multiplexer
BH ───────── topology / margin annotation ───────┤
BCRC-PGRC ───── explicit certificate status ─────┘
                                                   ↓
                                      Contract and role validation
                                                   ↓
                                  Evidence/certificate eligibility check
                                                   ↓
                                  Conflict detection; no hidden arbitration
                                                   ↓
                                   Domain/host adapter capability binding
```

## Negotiation

The current negotiation rule selects the highest exact version shared by the registered contract and the branch offer. Unknown branches, mismatched contract IDs, and incompatible versions are rejected explicitly.

## Branch isolation

A branch may emit only message types declared by its registered contract. For example, a BH message labelled `ACTION_INTENT` is rejected before routing.

## Action path

OBS policy advisory is preserved for AI-8 or downstream audit, but is not a peer executable action. Only AI-8 `ACTION_INTENT` enters the current host-binding path.

## Semantic-loss ledger

Every accepted or rejected message receives an explicit ledger entry. Reason and confidence are not placed inside the host command payload, but remain available in an audit sidecar and are therefore classified as `AUDIT_SIDECAR_ONLY`, not silently discarded.
