# GCF-UMA v0.1b Result Memo

Verdict: `TRANSACTIONAL_SESSION_REPLAY_PROTECTION_FAILURE_RECOVERY_PASS`

## Formal results

- v0.1b transactional gates: **16/16 PASS**
- total unit/regression tests: **46/46 PASS**
- original v0.1 adapter tests retained: 10/10 PASS
- v0.1a multiplex tests retained: 20/20 PASS
- new v0.1b transaction tests: 16/16 PASS

## Validated in the locked mock harness

- active branch-session identity and retired-session rejection;
- monotonic sequence handling;
- duplicate/replayed message rejection;
- issued-at, maximum-age, and explicit-expiry checks;
- transaction deadline capped by input freshness;
- side-effect-free prepare;
- approval-required commit;
- idempotent repeated commit with one host execution;
- explicit abort and timeout with zero execution;
- partial branch-outage isolation;
- `PENDING_INPUT → supplement → PENDING_APPROVAL → COMMITTED` recovery;
- explicit reversible rollback and idempotent repeated rollback;
- hash-chained audit receipt tamper detection;
- preservation of host capability, authority, magnitude, and ramp constraints;
- invalid branch-role message isolation without dropping valid messages.

## Important design finding

Failure isolation alone was insufficient. An early implementation could block physical binding while OBS/BCRC-PGRC were offline, but could not recover the same transaction after those branches returned. v0.1b therefore adds supplementary input handling. Fresh messages are revalidated and the complete multiplex/eligibility path is rerun; no gate is bypassed.

## Transaction semantics

`prepare` is a preview. It does not modify Adapter ramp state and does not execute the Mock Host. Only `commit` may modify host-binding state. Approval-required outputs remain non-executable until explicit approval is supplied to the transaction coordinator.

## Boundary

This is a deterministic mock transaction and integration-contract result. It does not establish distributed atomicity, real transport reliability, cryptographic branch identity, host crash recovery, persistent storage durability, independent certificate truth, Safety Governor authorization, or real energy/fusion/6G deployment safety.
