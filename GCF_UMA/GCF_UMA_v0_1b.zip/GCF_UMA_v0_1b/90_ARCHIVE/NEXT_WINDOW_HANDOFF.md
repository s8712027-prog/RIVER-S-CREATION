# Next Window Handoff

Current branch: `GCF-UMA v0.1b`.

Locked status: `TRANSACTIONAL_SESSION_REPLAY_PROTECTION_FAILURE_RECOVERY_PASS`.

Formal results: 16/16 transactional gates, 46/46 total unit/regression tests.

Next candidate: `GCF-UMA v0.1c — Durable Journal, Crash Recovery, and Multi-Host Commit Boundaries`.

Priorities:
1. append-only durable transaction journal;
2. restart/replay reconstruction from journal;
3. prepared-but-not-committed crash cases;
4. host execution receipt reconciliation;
5. compensation failure and irreversible-operation boundary;
6. multiple host plugins without claiming distributed atomicity;
7. explicit best-effort versus atomic capability declaration;
8. persistence corruption and checkpoint audit.

Do not add branch inference, AI-8 route calculation, BH/BCRC logic, or Safety Governor policy into UMA.
