# Next Window Handoff

Current branch: GCF-UMA v0.1.
Next candidate: v0.1a Branch Multiplexing and Contract Negotiation.
Priorities:
1. multiple simultaneous branch contracts (OBS, AI-8, BH, BCRC/PGRC)
2. contract-version negotiation
3. profile composition conflict detection
4. bidirectional semantic-loss ledger
5. negative tests for hidden branch logic
6. host-plugin interface
