from dataclasses import dataclass, field
from typing import Any, Dict

@dataclass(frozen=True)
class GenericIntent:
    intent: str
    target: str
    magnitude: float
    reason: str = ""
    provenance: Dict[str, Any] = field(default_factory=dict)

@dataclass(frozen=True)
class BoundOutput:
    host_operation: str
    target: str
    magnitude: float
    authority_mode: str
    executable: bool
    approval_required: bool
    provenance: Dict[str, Any]
