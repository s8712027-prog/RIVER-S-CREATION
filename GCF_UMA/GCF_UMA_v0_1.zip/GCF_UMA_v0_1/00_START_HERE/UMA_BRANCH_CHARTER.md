# GCF-UMA Branch Charter

## Core responsibility
GCF-UMA is an integration middleware branch. It maps explicit domain profiles and host profiles to stable generic contracts.

## Non-responsibilities
- no structural-risk inference
- no state forecasting
- no action selection
- no safety approval
- no certificate generation
- no domain optimization

## Architectural rule
Every transformation must be profile-declared, validated, provenance-preserving, reversible where semantically possible, and rejected when unsupported.
