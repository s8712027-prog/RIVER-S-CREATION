# GCF-UMA v0.1 — Universal Multi-Domain Adapter Foundation

Status: `UNIVERSAL_MULTI_DOMAIN_ADAPTER_FOUNDATION_CANDIDATE`

Purpose: provide reusable, auditable translation between domain/host systems and GCF branch contracts without embedding branch-native inference or control logic.

Initial validation profiles:
- Mock Small-Energy / Fusion Management
- Mock 6G Base-Station Management

The adapter kernel performs schema translation, unit normalization, provenance preservation, capability/authority enforcement, constraint validation, and output binding. It does not calculate OBS risk, AI-8 routing, BH margins, BCRC/PGRC certificates, or host-control optimization.
