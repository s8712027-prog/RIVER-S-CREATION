from __future__ import annotations

from copy import deepcopy
from dataclasses import asdict
import hashlib
import json
import os
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional

from .models import BranchEnvelope, MultiplexResult, TransactionRecord
from .transactional import MockTransactionalHost, TransactionCoordinator, TransactionError


class JournalError(ValueError):
    pass


def _stable_hash(payload: Dict[str, Any]) -> str:
    raw = json.dumps(payload, sort_keys=True, separators=(",", ":"), default=str).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


class AppendOnlyJournal:
    """Small deterministic JSONL journal with a hash chain and fsync.

    This is a local durability harness. It is not a replicated log, database WAL,
    cryptographic signature system, or distributed consensus protocol.
    """

    def __init__(self, path: str | Path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        if not self.path.exists():
            self.path.touch()
        self.records: List[Dict[str, Any]] = []
        self.truncated_tail_ignored = False
        self._load()

    def _load(self) -> None:
        self.records = []
        self.truncated_tail_ignored = False
        lines = self.path.read_text(encoding="utf-8").splitlines()
        valid_lines: List[str] = []
        prior = "GENESIS"
        expected_sequence = 1
        for index, line in enumerate(lines):
            if not line.strip():
                continue
            try:
                record = json.loads(line)
            except json.JSONDecodeError as exc:
                if index == len(lines) - 1:
                    self.truncated_tail_ignored = True
                    # Crash recovery may remove only an incomplete final record.
                    repaired = ("\n".join(valid_lines) + ("\n" if valid_lines else ""))
                    with self.path.open("w", encoding="utf-8") as handle:
                        handle.write(repaired)
                        handle.flush()
                        os.fsync(handle.fileno())
                    break
                raise JournalError(f"invalid journal JSON at line {index + 1}") from exc
            if record.get("sequence") != expected_sequence:
                raise JournalError("journal sequence discontinuity")
            if record.get("previous_hash") != prior:
                raise JournalError("journal previous-hash mismatch")
            expected = deepcopy(record)
            actual_hash = expected.pop("record_hash", None)
            if _stable_hash(expected) != actual_hash:
                raise JournalError("journal record hash mismatch")
            self.records.append(record)
            valid_lines.append(line)
            prior = actual_hash
            expected_sequence += 1

    def append(self, event_type: str, payload: Dict[str, Any], timestamp: float) -> Dict[str, Any]:
        prior = self.records[-1]["record_hash"] if self.records else "GENESIS"
        record = {
            "sequence": len(self.records) + 1,
            "event_type": str(event_type),
            "timestamp": float(timestamp),
            "payload": deepcopy(payload),
            "previous_hash": prior,
        }
        record["record_hash"] = _stable_hash(record)
        encoded = json.dumps(record, sort_keys=True, separators=(",", ":"), default=str)
        with self.path.open("a", encoding="utf-8") as handle:
            handle.write(encoded + "\n")
            handle.flush()
            os.fsync(handle.fileno())
        self.records.append(deepcopy(record))
        return record

    def verify(self) -> bool:
        prior = "GENESIS"
        for sequence, record in enumerate(self.records, start=1):
            if record.get("sequence") != sequence or record.get("previous_hash") != prior:
                return False
            expected = deepcopy(record)
            actual = expected.pop("record_hash", None)
            if _stable_hash(expected) != actual:
                return False
            prior = actual
        return True

    def events(self, event_type: Optional[str] = None) -> List[Dict[str, Any]]:
        if event_type is None:
            return deepcopy(self.records)
        return [deepcopy(record) for record in self.records if record.get("event_type") == event_type]


class JournaledMockHost(MockTransactionalHost):
    """Mock host whose execution receipts survive coordinator restart."""

    def __init__(self, journal: AppendOnlyJournal, rollback_bindings: Optional[Dict[str, str]] = None):
        self.journal = journal
        super().__init__(rollback_bindings=rollback_bindings)
        self._restore()

    def _restore(self) -> None:
        self.executions = {}
        self.idempotency_index = {}
        self.execution_order = []
        for event in self.journal.records:
            payload = event.get("payload", {})
            if event.get("event_type") == "HOST_EXECUTION":
                receipt = deepcopy(payload["receipt"])
                execution_id = receipt["execution_id"]
                self.executions[execution_id] = receipt
                self.idempotency_index[receipt["idempotency_key"]] = execution_id
                if execution_id not in self.execution_order:
                    self.execution_order.append(execution_id)
            elif event.get("event_type") == "HOST_ROLLBACK":
                execution_id = payload["execution_id"]
                if execution_id in self.executions:
                    self.executions[execution_id]["state"] = "ROLLED_BACK"
                    self.executions[execution_id]["rollback_receipt"] = deepcopy(payload["receipt"])

    def execute(self, bound_output: Dict[str, Any], idempotency_key: str, now: float) -> Dict[str, Any]:
        existed = idempotency_key in self.idempotency_index
        receipt = super().execute(bound_output, idempotency_key, now)
        if not existed:
            self.journal.append("HOST_EXECUTION", {"receipt": deepcopy(receipt)}, now)
        return receipt

    def rollback(self, execution_id: str, now: float) -> Dict[str, Any]:
        already = execution_id in self.executions and self.executions[execution_id].get("state") == "ROLLED_BACK"
        receipt = super().rollback(execution_id, now)
        if not already:
            self.journal.append("HOST_ROLLBACK", {"execution_id": execution_id, "receipt": deepcopy(receipt)}, now)
        return receipt


class DurableTransactionCoordinator:
    """Journal-backed wrapper for the existing deterministic coordinator."""

    def __init__(self, coordinator: TransactionCoordinator, journal: AppendOnlyJournal):
        self.coordinator = coordinator
        self.journal = journal
        self.recovered_from_journal = False
        self.reconciliation_events: List[Dict[str, Any]] = []
        if self.journal.records:
            self.restore_latest_snapshot()

    @property
    def transactions(self):
        return self.coordinator.transactions

    @property
    def host(self):
        return self.coordinator.host

    def _serialize_guard(self) -> Dict[str, Any]:
        guard = self.coordinator.replay_guard
        return {
            "active_sessions": deepcopy(guard.active_sessions),
            "retired_sessions": {k: sorted(v) for k, v in guard.retired_sessions.items()},
            "last_sequence": [
                {"branch_id": branch, "session_id": session, "sequence": sequence}
                for (branch, session), sequence in sorted(guard.last_sequence.items())
            ],
            "seen_message_ids": [
                {"branch_id": branch, "session_id": session, "message_id": message}
                for branch, session, message in sorted(guard.seen_message_ids)
            ],
        }

    @staticmethod
    def _serialize_envelope(envelope: BranchEnvelope) -> Dict[str, Any]:
        return asdict(envelope)

    def _snapshot_payload(self) -> Dict[str, Any]:
        return {
            "guard": self._serialize_guard(),
            "transactions": {key: value.to_dict() for key, value in self.coordinator.transactions.items()},
            "transaction_inputs": {
                key: [self._serialize_envelope(item) for item in value]
                for key, value in self.coordinator._transaction_inputs.items()
            },
            "receipt_chain": deepcopy(self.coordinator.receipt_chain),
            "adapter_state": self.coordinator.host_plugin.adapter.export_state(),
        }

    def snapshot(self, now: float, reason: str) -> Dict[str, Any]:
        return self.journal.append(
            "COORDINATOR_SNAPSHOT",
            {"reason": reason, "state": self._snapshot_payload()},
            now,
        )

    def restore_latest_snapshot(self) -> bool:
        snapshots = self.journal.events("COORDINATOR_SNAPSHOT")
        if not snapshots:
            return False
        state = snapshots[-1]["payload"]["state"]
        guard_state = state["guard"]
        guard = self.coordinator.replay_guard
        guard.active_sessions = {str(k): str(v) for k, v in guard_state["active_sessions"].items()}
        guard.retired_sessions = {str(k): set(v) for k, v in guard_state["retired_sessions"].items()}
        guard.last_sequence = {
            (item["branch_id"], item["session_id"]): int(item["sequence"])
            for item in guard_state["last_sequence"]
        }
        guard.seen_message_ids = {
            (item["branch_id"], item["session_id"], item["message_id"])
            for item in guard_state["seen_message_ids"]
        }
        self.coordinator.transactions = {
            transaction_id: TransactionRecord(**payload)
            for transaction_id, payload in state["transactions"].items()
        }
        self.coordinator._transaction_inputs = {
            transaction_id: [BranchEnvelope(**item) for item in payload]
            for transaction_id, payload in state["transaction_inputs"].items()
        }
        self.coordinator.receipt_chain = deepcopy(state["receipt_chain"])
        self.coordinator.host_plugin.adapter.import_state(state.get("adapter_state", {}))
        self.recovered_from_journal = True
        return True

    def open_session(self, branch_id: str, session_id: str, now: float = 0.0) -> None:
        self.coordinator.open_session(branch_id, session_id)
        self.snapshot(now, "OPEN_SESSION")

    def begin(self, transaction_id: str, envelopes: Iterable[BranchEnvelope], now: float, timeout: Optional[float] = None) -> TransactionRecord:
        record = self.coordinator.begin(transaction_id, envelopes, now, timeout)
        self.snapshot(now, "BEGIN")
        return record

    def supplement(self, transaction_id: str, envelopes: Iterable[BranchEnvelope], now: float) -> TransactionRecord:
        record = self.coordinator.supplement(transaction_id, envelopes, now)
        self.snapshot(now, "SUPPLEMENT")
        return record

    def commit(self, transaction_id: str, now: float, approval: bool = False) -> Dict[str, Any]:
        receipt = self.coordinator.commit(transaction_id, now, approval)
        self.snapshot(now, "COMMIT")
        return receipt

    def abort(self, transaction_id: str, now: float, reason: str) -> Dict[str, Any]:
        receipt = self.coordinator.abort(transaction_id, now, reason)
        self.snapshot(now, "ABORT")
        return receipt

    def rollback(self, transaction_id: str, now: float) -> Dict[str, Any]:
        receipt = self.coordinator.rollback(transaction_id, now)
        self.snapshot(now, "ROLLBACK")
        return receipt

    def expire_pending(self, now: float) -> List[str]:
        expired = self.coordinator.expire_pending(now)
        if expired:
            self.snapshot(now, "EXPIRE_PENDING")
        return expired

    def simulate_crash_after_host_execution(self, transaction_id: str, now: float, approval: bool = False) -> List[Dict[str, Any]]:
        """Test-only crash point: persist host receipts but no coordinator commit snapshot."""
        if transaction_id not in self.coordinator.transactions:
            raise TransactionError("unknown transaction")
        record = self.coordinator.transactions[transaction_id]
        if record.state == "PENDING_APPROVAL" and not approval:
            raise TransactionError("approval required")
        if record.state not in ("PREPARED", "PENDING_APPROVAL"):
            raise TransactionError(f"transaction is not executable from {record.state}")
        mux = MultiplexResult(status=record.multiplex_result.get("status", "PASS"))
        mux.selected_actions = deepcopy(record.selected_actions)
        actual_binding = self.coordinator.host_plugin.bind(mux, commit_state=True)
        executions: List[Dict[str, Any]] = []
        for index, item in enumerate(actual_binding["bound"]):
            item = deepcopy(item)
            item["approval_granted"] = bool(approval and item.get("approval_required"))
            key = _stable_hash({
                "transaction_id": transaction_id,
                "index": index,
                "operation": item["host_operation"],
                "target": item["target"],
            })
            executions.append(self.coordinator.host.execute(item, key, now))
        return executions

    def reconcile_host_receipts(self, now: float) -> List[Dict[str, Any]]:
        reconciled: List[Dict[str, Any]] = []
        for transaction_id, record in self.coordinator.transactions.items():
            if record.state not in ("PREPARED", "PENDING_APPROVAL"):
                continue
            expected: List[tuple[str, Dict[str, Any], Dict[str, Any]]] = []
            preview_bound = record.preview_binding.get("bound", [])
            for index, item in enumerate(preview_bound):
                key = _stable_hash({
                    "transaction_id": transaction_id,
                    "index": index,
                    "operation": item["host_operation"],
                    "target": item["target"],
                })
                expected.append((key, item, record.selected_actions[index] if index < len(record.selected_actions) else {}))
            present = [key in self.coordinator.host.idempotency_index for key, _, _ in expected]
            if expected and all(present):
                executions = [
                    deepcopy(self.coordinator.host.executions[self.coordinator.host.idempotency_index[key]])
                    for key, _, _ in expected
                ]
                adapter_state = self.coordinator.host_plugin.adapter.export_state()
                for (_, bound, action) in expected:
                    intent = action.get("intent")
                    if intent:
                        adapter_state[intent] = float(bound["magnitude"])
                self.coordinator.host_plugin.adapter.import_state(adapter_state)
                record.state = "COMMITTED"
                receipt = self.coordinator._append_receipt({
                    "transaction_id": transaction_id,
                    "state": "COMMITTED",
                    "time": now,
                    "executions": executions,
                    "binding": deepcopy(record.preview_binding),
                    "reconciled_from_host_receipts": True,
                    "idempotent_replay": False,
                })
                record.commit_receipt = deepcopy(receipt)
                event = {"transaction_id": transaction_id, "result": "COMMITTED_FROM_HOST_RECEIPTS"}
                reconciled.append(event)
                self.reconciliation_events.append(deepcopy(event))
            elif any(present):
                record.state = "HOST_RECONCILIATION_REQUIRED"
                record.abort_reason = "PARTIAL_HOST_EXECUTION"
                event = {"transaction_id": transaction_id, "result": "MANUAL_RECONCILIATION_REQUIRED"}
                reconciled.append(event)
                self.reconciliation_events.append(deepcopy(event))
        if reconciled:
            self.snapshot(now, "HOST_RECEIPT_RECONCILIATION")
        return reconciled
