from __future__ import annotations

from copy import deepcopy
import hashlib
import json
from typing import Any, Dict, List, Optional

from .durable import AppendOnlyJournal


class MultiHostError(ValueError):
    pass


def _stable_hash(payload: Dict[str, Any]) -> str:
    raw = json.dumps(payload, sort_keys=True, separators=(",", ":"), default=str).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


class MockHostEndpoint:
    def __init__(
        self,
        host_id: str,
        atomic_capable: bool = False,
        rollback_bindings: Optional[Dict[str, str]] = None,
        fail_operations: Optional[List[str]] = None,
        rollback_fail_operations: Optional[List[str]] = None,
    ):
        self.host_id = host_id
        self.atomic_capable = bool(atomic_capable)
        self.rollback_bindings = rollback_bindings or {}
        self.fail_operations = set(fail_operations or [])
        self.rollback_fail_operations = set(rollback_fail_operations or [])
        self.executions: Dict[str, Dict[str, Any]] = {}
        self.idempotency_index: Dict[str, str] = {}

    def reversible(self, operation: str) -> bool:
        return operation in self.rollback_bindings

    def execute(self, command: Dict[str, Any], idempotency_key: str, now: float) -> Dict[str, Any]:
        if idempotency_key in self.idempotency_index:
            result = deepcopy(self.executions[self.idempotency_index[idempotency_key]])
            result["idempotent_replay"] = True
            return result
        operation = command["host_operation"]
        if operation in self.fail_operations:
            raise MultiHostError(f"host {self.host_id} injected failure for {operation}")
        execution_id = f"{self.host_id}-exec-{len(self.executions)+1:04d}"
        receipt = {
            "execution_id": execution_id,
            "host_id": self.host_id,
            "host_operation": operation,
            "target": command["target"],
            "magnitude": float(command.get("magnitude", 0.0)),
            "executed_at": float(now),
            "state": "EXECUTED",
            "idempotent_replay": False,
        }
        self.executions[execution_id] = deepcopy(receipt)
        self.idempotency_index[idempotency_key] = execution_id
        return receipt

    def rollback(self, execution_id: str, now: float) -> Dict[str, Any]:
        if execution_id not in self.executions:
            raise MultiHostError("unknown execution")
        execution = self.executions[execution_id]
        if execution.get("state") == "ROLLED_BACK":
            return deepcopy(execution["rollback_receipt"])
        operation = execution["host_operation"]
        if operation not in self.rollback_bindings:
            raise MultiHostError(f"irreversible operation: {operation}")
        if operation in self.rollback_fail_operations:
            raise MultiHostError(f"rollback failure for {operation}")
        receipt = {
            "execution_id": execution_id,
            "host_id": self.host_id,
            "rollback_operation": self.rollback_bindings[operation],
            "rolled_back_at": float(now),
            "state": "ROLLED_BACK",
        }
        execution["state"] = "ROLLED_BACK"
        execution["rollback_receipt"] = deepcopy(receipt)
        return receipt


class MultiHostCommitCoordinator:
    """Explicit multi-host boundary model.

    BEST_EFFORT means sequential execution plus compensation where possible.
    DECLARED_ATOMIC_SIMULATION is accepted only if every endpoint declares an
    atomic capability. It is still a local mock, not distributed atomic commit.
    """

    def __init__(self, endpoints: Dict[str, MockHostEndpoint], journal: Optional[AppendOnlyJournal] = None):
        self.endpoints = endpoints
        self.journal = journal
        self.transactions: Dict[str, Dict[str, Any]] = {}

    def _record(self, event: str, payload: Dict[str, Any], now: float) -> None:
        if self.journal is not None:
            self.journal.append(event, payload, now)

    def prepare(
        self,
        transaction_id: str,
        commands: List[Dict[str, Any]],
        mode: str,
        now: float,
        allow_irreversible_boundary: bool = False,
    ) -> Dict[str, Any]:
        if transaction_id in self.transactions:
            raise MultiHostError("transaction_id already exists")
        if mode not in ("BEST_EFFORT", "DECLARED_ATOMIC_SIMULATION"):
            raise MultiHostError("unsupported multi-host mode")
        if not commands:
            raise MultiHostError("commands must be non-empty")
        for command in commands:
            if command["host_id"] not in self.endpoints:
                raise MultiHostError(f"unknown host: {command['host_id']}")
        if mode == "DECLARED_ATOMIC_SIMULATION" and not all(self.endpoints[c["host_id"]].atomic_capable for c in commands):
            record = {"transaction_id": transaction_id, "state": "ABORTED", "reason": "ATOMIC_CAPABILITY_NOT_SHARED", "mode": mode, "commands": deepcopy(commands)}
            self.transactions[transaction_id] = record
            self._record("MULTI_HOST_PREPARE_ABORT", record, now)
            return deepcopy(record)
        irreversible = [
            index for index, command in enumerate(commands)
            if not self.endpoints[command["host_id"]].reversible(command["host_operation"])
        ]
        if mode == "BEST_EFFORT" and irreversible:
            valid_boundary = allow_irreversible_boundary and len(irreversible) == 1 and irreversible[0] == len(commands) - 1
            if not valid_boundary:
                record = {"transaction_id": transaction_id, "state": "ABORTED", "reason": "IRREVERSIBLE_BOUNDARY_VIOLATION", "mode": mode, "commands": deepcopy(commands)}
                self.transactions[transaction_id] = record
                self._record("MULTI_HOST_PREPARE_ABORT", record, now)
                return deepcopy(record)
        record = {
            "transaction_id": transaction_id,
            "state": "PREPARED",
            "mode": mode,
            "commands": deepcopy(commands),
            "allow_irreversible_boundary": bool(allow_irreversible_boundary),
            "executions": [],
            "compensations": [],
            "failures": [],
        }
        self.transactions[transaction_id] = record
        self._record("MULTI_HOST_PREPARED", record, now)
        return deepcopy(record)

    def commit(self, transaction_id: str, now: float) -> Dict[str, Any]:
        if transaction_id not in self.transactions:
            raise MultiHostError("unknown transaction")
        record = self.transactions[transaction_id]
        if record["state"] == "COMMITTED":
            result = deepcopy(record)
            result["idempotent_replay"] = True
            return result
        if record["state"] != "PREPARED":
            raise MultiHostError(f"transaction cannot commit from {record['state']}")
        executed: List[tuple[Dict[str, Any], Dict[str, Any]]] = []
        try:
            for index, command in enumerate(record["commands"]):
                endpoint = self.endpoints[command["host_id"]]
                key = _stable_hash({"transaction_id": transaction_id, "index": index, "host_id": command["host_id"], "operation": command["host_operation"], "target": command["target"]})
                receipt = endpoint.execute(command, key, now)
                executed.append((command, receipt))
                record["executions"].append(deepcopy(receipt))
        except MultiHostError as exc:
            record["failures"].append(str(exc))
            compensation_failed = False
            for command, receipt in reversed(executed):
                endpoint = self.endpoints[command["host_id"]]
                if not endpoint.reversible(command["host_operation"]):
                    compensation_failed = True
                    record["failures"].append(f"irreversible committed operation: {command['host_operation']}")
                    continue
                try:
                    rollback = endpoint.rollback(receipt["execution_id"], now)
                    record["compensations"].append(deepcopy(rollback))
                except MultiHostError as rollback_exc:
                    compensation_failed = True
                    record["failures"].append(str(rollback_exc))
            record["state"] = "MANUAL_RECONCILIATION_REQUIRED" if compensation_failed else "ABORTED_COMPENSATED"
            self._record("MULTI_HOST_COMMIT_FAILURE", record, now)
            return deepcopy(record)
        record["state"] = "COMMITTED"
        record["idempotent_replay"] = False
        self._record("MULTI_HOST_COMMITTED", record, now)
        return deepcopy(record)
