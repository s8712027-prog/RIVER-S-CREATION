from __future__ import annotations

import json
from pathlib import Path
import tempfile
import sys

ROOT = Path(__file__).resolve().parent
PKG = ROOT.parent
sys.path.insert(0, str(ROOT))

from gcf_uma import (
    AdapterHostPlugin,
    AppendOnlyJournal,
    BranchEnvelope,
    BranchMultiplexer,
    ContractRegistry,
    DurableTransactionCoordinator,
    JournaledMockHost,
    MockBranchTransport,
    MockHostEndpoint,
    MultiHostCommitCoordinator,
    SessionReplayGuard,
    TransactionCoordinator,
    UniversalAdapter,
)


def build(root: Path):
    registry = ContractRegistry.from_directory(PKG / "15_BRANCH_CONTRACTS")
    mux = BranchMultiplexer.from_yaml(registry, PKG / "20_PROFILES" / "branch_multiplex_profile.yaml")
    adapter = UniversalAdapter.from_yaml(PKG / "20_PROFILES" / "mock_energy_profile.yaml")
    plugin = AdapterHostPlugin(adapter)
    guard = SessionReplayGuard.from_yaml(PKG / "20_PROFILES" / "transaction_session_profile.yaml")
    host = JournaledMockHost(AppendOnlyJournal(root / "host.jsonl"), {"energy.request_sensor_refresh": "energy.cancel_sensor_refresh"})
    coord = TransactionCoordinator.from_yaml(mux, plugin, guard, host, PKG / "20_PROFILES" / "transaction_session_profile.yaml", transport=MockBranchTransport())
    return DurableTransactionCoordinator(coord, AppendOnlyJournal(root / "coord.jsonl"))


def main():
    with tempfile.TemporaryDirectory() as temp:
        root = Path(temp)
        durable = build(root)
        for branch, session in (("OBS-CoreV2", "obs"), ("AI-8", "ai"), ("BH", "bh"), ("BCRC-PGRC", "cert")):
            durable.open_session(branch, session, 99.0)
        action = BranchEnvelope(
            "a1", "AI-8", "GCF_AI8_ACTION_ROUTER_CONTRACT", "0.5d", "ACTION_INTENT",
            {"intent": "REQUEST_OBSERVATION", "target": "telemetry", "magnitude": 1.0, "reason": "demo", "confidence": 0.9},
            50, {"demo": True}, "ai", 1, 100.0, None,
        )
        durable.begin("tx-demo", [action], 100.0)
        durable.simulate_crash_after_host_execution("tx-demo", 100.1)
        recovered = build(root)
        reconciliation = recovered.reconcile_host_receipts(100.2)

        a = MockHostEndpoint("energy", rollback_bindings={"energy.limit": "energy.restore"})
        b = MockHostEndpoint("ran", rollback_bindings={"ran.limit": "ran.restore"})
        multi = MultiHostCommitCoordinator({"energy": a, "ran": b}, AppendOnlyJournal(root / "multi.jsonl"))
        multi.prepare("multi-demo", [
            {"host_id": "energy", "host_operation": "energy.limit", "target": "aux", "magnitude": 0.1},
            {"host_id": "ran", "host_operation": "ran.limit", "target": "traffic", "magnitude": 0.1},
        ], "BEST_EFFORT", 101.0)
        multi_result = multi.commit("multi-demo", 101.1)
        payload = {
            "crash_recovery": {
                "reconciliation": reconciliation,
                "transaction_state": recovered.transactions["tx-demo"].state,
                "host_execution_count": len(recovered.host.executions),
                "coordinator_journal_verified": recovered.journal.verify(),
            },
            "multi_host": {
                "state": multi_result["state"],
                "mode": multi_result["mode"],
                "execution_count": len(multi_result["executions"]),
            },
        }
        out = PKG / "50_RESULTS" / "DURABLE_MULTI_HOST_DEMO_OUTPUT.json"
        out.write_text(json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8")
        print(json.dumps(payload, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
