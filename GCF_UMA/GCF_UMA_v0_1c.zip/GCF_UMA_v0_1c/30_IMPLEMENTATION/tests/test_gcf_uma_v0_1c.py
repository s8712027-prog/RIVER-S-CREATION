from __future__ import annotations

import hashlib
import json
from pathlib import Path
import tempfile
import unittest

IMPL = Path(__file__).resolve().parents[1]
PKG = IMPL.parent
import sys
sys.path.insert(0, str(IMPL))

from gcf_uma import (
    AdapterHostPlugin,
    AppendOnlyJournal,
    BranchEnvelope,
    BranchMultiplexer,
    ContractRegistry,
    DurableTransactionCoordinator,
    JournalError,
    JournaledMockHost,
    MockBranchTransport,
    MockHostEndpoint,
    MultiHostCommitCoordinator,
    SessionReplayGuard,
    TransactionCoordinator,
    UniversalAdapter,
)

CONTRACTS = PKG / "15_BRANCH_CONTRACTS"
PROFILES = PKG / "20_PROFILES"


def stable_hash(payload):
    raw = json.dumps(payload, sort_keys=True, separators=(",", ":"), default=str).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


class DurableHarness:
    def __init__(self, root: Path):
        self.root = root
        self.coord_path = root / "coordinator.jsonl"
        self.host_path = root / "host.jsonl"

    def build(self) -> DurableTransactionCoordinator:
        registry = ContractRegistry.from_directory(CONTRACTS)
        mux = BranchMultiplexer.from_yaml(registry, PROFILES / "branch_multiplex_profile.yaml")
        adapter = UniversalAdapter.from_yaml(PROFILES / "mock_energy_profile.yaml")
        plugin = AdapterHostPlugin(adapter)
        guard = SessionReplayGuard.from_yaml(PROFILES / "transaction_session_profile.yaml")
        transport = MockBranchTransport()
        host = JournaledMockHost(
            AppendOnlyJournal(self.host_path),
            {"energy.request_sensor_refresh": "energy.cancel_sensor_refresh"},
        )
        coordinator = TransactionCoordinator.from_yaml(
            mux,
            plugin,
            guard,
            host,
            PROFILES / "transaction_session_profile.yaml",
            transport=transport,
        )
        return DurableTransactionCoordinator(coordinator, AppendOnlyJournal(self.coord_path))


class TestUMAV01C(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.harness = DurableHarness(self.root)
        self.durable = self.harness.build()
        for branch, session in (("OBS-CoreV2", "obs-s1"), ("AI-8", "ai-s1"), ("BH", "bh-s1"), ("BCRC-PGRC", "cert-s1")):
            self.durable.open_session(branch, session, now=99.0)
        self.now = 100.0

    def tearDown(self):
        self.temp.cleanup()

    def env(self, branch, msg_id, msg_type, payload, seq, issued=None, expires=None, session=None):
        defaults = {
            "OBS-CoreV2": ("GCF_OBS_COREV2_ADAPTER_CONTRACT", "0.1k", "obs-s1"),
            "AI-8": ("GCF_AI8_ACTION_ROUTER_CONTRACT", "0.5d", "ai-s1"),
            "BH": ("GCF_BH_TOPOLOGY_MARGIN_CONTRACT", "PROV8A-v1.1", "bh-s1"),
            "BCRC-PGRC": ("GCF_BCRC_PGRC_CERTIFICATE_CONTRACT", "1.0", "cert-s1"),
        }
        contract, version, default_session = defaults[branch]
        return BranchEnvelope(
            msg_id, branch, contract, version, msg_type, payload, 50, {"test": self._testMethodName},
            session or default_session, seq, self.now if issued is None else issued, expires,
        )

    def action(self, seq=1, target="telemetry", intent="REQUEST_OBSERVATION", magnitude=1.0):
        return self.env("AI-8", f"a{seq}-{target}", "ACTION_INTENT", {"intent": intent, "target": target, "magnitude": magnitude, "reason": "test", "confidence": 0.9}, seq)

    def test_append_only_journal_reopens_and_verifies(self):
        path = self.root / "simple.jsonl"
        journal = AppendOnlyJournal(path)
        journal.append("A", {"x": 1}, 1.0)
        journal.append("B", {"x": 2}, 2.0)
        reopened = AppendOnlyJournal(path)
        self.assertTrue(reopened.verify())
        self.assertEqual([x["event_type"] for x in reopened.records], ["A", "B"])

    def test_journal_tampering_is_detected(self):
        path = self.root / "tampered.jsonl"
        journal = AppendOnlyJournal(path)
        journal.append("A", {"x": 1}, 1.0)
        data = path.read_text(encoding="utf-8").replace('"x":1', '"x":9')
        path.write_text(data, encoding="utf-8")
        with self.assertRaises(JournalError):
            AppendOnlyJournal(path)

    def test_truncated_tail_is_ignored_but_flagged(self):
        path = self.root / "tail.jsonl"
        journal = AppendOnlyJournal(path)
        journal.append("A", {"x": 1}, 1.0)
        with path.open("a", encoding="utf-8") as handle:
            handle.write('{"sequence":2')
        reopened = AppendOnlyJournal(path)
        self.assertTrue(reopened.truncated_tail_ignored)
        self.assertEqual(len(reopened.records), 1)
        self.assertTrue(reopened.verify())
        reopened.append("B", {"x": 2}, 2.0)
        self.assertEqual(len(AppendOnlyJournal(path).records), 2)

    def test_prepared_transaction_survives_restart_without_execution(self):
        record = self.durable.begin("t1", [self.action()], self.now)
        self.assertEqual(record.state, "PREPARED")
        recovered = self.harness.build()
        self.assertTrue(recovered.recovered_from_journal)
        self.assertEqual(recovered.transactions["t1"].state, "PREPARED")
        self.assertEqual(len(recovered.host.executions), 0)
        receipt = recovered.commit("t1", self.now + 0.1)
        self.assertEqual(receipt["state"], "COMMITTED")
        self.assertEqual(len(recovered.host.executions), 1)

    def test_session_and_replay_state_survive_restart(self):
        self.durable.begin("t1", [self.action(1)], self.now)
        recovered = self.harness.build()
        replay = self.env("AI-8", "new-id", "ACTION_INTENT", {"intent": "REQUEST_OBSERVATION", "target": "other", "magnitude": 1.0, "reason": "x", "confidence": 0.9}, 1, issued=self.now + 0.1)
        rec = recovered.begin("t2", [replay], self.now + 0.1)
        self.assertEqual(rec.transport_rejections[0]["reason"], "REPLAY_OR_OUT_OF_ORDER")

    def test_committed_transaction_is_idempotent_after_restart(self):
        self.durable.begin("t1", [self.action()], self.now)
        first = self.durable.commit("t1", self.now + 0.1)
        recovered = self.harness.build()
        second = recovered.commit("t1", self.now + 0.2)
        self.assertEqual(first["receipt_hash"], second["receipt_hash"])
        self.assertTrue(second["idempotent_replay"])
        self.assertEqual(len(recovered.host.executions), 1)

    def test_host_receipt_reconciliation_closes_commit_crash_window(self):
        self.durable.begin("t1", [self.action()], self.now)
        executed = self.durable.simulate_crash_after_host_execution("t1", self.now + 0.1)
        self.assertEqual(len(executed), 1)
        recovered = self.harness.build()
        self.assertEqual(recovered.transactions["t1"].state, "PREPARED")
        events = recovered.reconcile_host_receipts(self.now + 0.2)
        self.assertEqual(events[0]["result"], "COMMITTED_FROM_HOST_RECEIPTS")
        self.assertEqual(recovered.transactions["t1"].state, "COMMITTED")
        again = recovered.commit("t1", self.now + 0.3)
        self.assertTrue(again["idempotent_replay"])
        self.assertEqual(len(recovered.host.executions), 1)

    def test_partial_host_receipt_requires_manual_reconciliation(self):
        actions = [self.action(1, target="telemetry-a"), self.action(2, target="telemetry-b")]
        rec = self.durable.begin("t1", actions, self.now)
        self.assertEqual(rec.state, "PREPARED")
        item = rec.preview_binding["bound"][0]
        key = stable_hash({"transaction_id": "t1", "index": 0, "operation": item["host_operation"], "target": item["target"]})
        self.durable.host.execute(item, key, self.now + 0.1)
        recovered = self.harness.build()
        events = recovered.reconcile_host_receipts(self.now + 0.2)
        self.assertEqual(events[0]["result"], "MANUAL_RECONCILIATION_REQUIRED")
        self.assertEqual(recovered.transactions["t1"].state, "HOST_RECONCILIATION_REQUIRED")

    def test_timeout_is_recovered_and_expired_without_execution(self):
        self.durable.begin("t1", [self.action()], self.now, timeout=1.0)
        recovered = self.harness.build()
        expired = recovered.expire_pending(self.now + 2.0)
        self.assertEqual(expired, ["t1"])
        self.assertEqual(recovered.transactions["t1"].state, "TIMED_OUT")
        self.assertEqual(len(recovered.host.executions), 0)

    def test_multi_host_best_effort_success_and_idempotency(self):
        a = MockHostEndpoint("A", rollback_bindings={"a.set": "a.undo"})
        b = MockHostEndpoint("B", rollback_bindings={"b.set": "b.undo"})
        coord = MultiHostCommitCoordinator({"A": a, "B": b})
        commands = [
            {"host_id": "A", "host_operation": "a.set", "target": "x", "magnitude": 0.1},
            {"host_id": "B", "host_operation": "b.set", "target": "y", "magnitude": 0.2},
        ]
        prep = coord.prepare("m1", commands, "BEST_EFFORT", 1.0)
        self.assertEqual(prep["state"], "PREPARED")
        first = coord.commit("m1", 2.0)
        second = coord.commit("m1", 3.0)
        self.assertEqual(first["state"], "COMMITTED")
        self.assertTrue(second["idempotent_replay"])
        self.assertEqual(len(a.executions) + len(b.executions), 2)

    def test_declared_atomic_requires_shared_capability(self):
        a = MockHostEndpoint("A", atomic_capable=True, rollback_bindings={"a.set": "a.undo"})
        b = MockHostEndpoint("B", atomic_capable=False, rollback_bindings={"b.set": "b.undo"})
        coord = MultiHostCommitCoordinator({"A": a, "B": b})
        prep = coord.prepare("m1", [
            {"host_id": "A", "host_operation": "a.set", "target": "x", "magnitude": 0.1},
            {"host_id": "B", "host_operation": "b.set", "target": "y", "magnitude": 0.2},
        ], "DECLARED_ATOMIC_SIMULATION", 1.0)
        self.assertEqual(prep["state"], "ABORTED")
        self.assertEqual(prep["reason"], "ATOMIC_CAPABILITY_NOT_SHARED")

    def test_declared_atomic_simulation_succeeds_when_all_declare(self):
        a = MockHostEndpoint("A", atomic_capable=True, rollback_bindings={"a.set": "a.undo"})
        b = MockHostEndpoint("B", atomic_capable=True, rollback_bindings={"b.set": "b.undo"})
        coord = MultiHostCommitCoordinator({"A": a, "B": b})
        coord.prepare("m1", [
            {"host_id": "A", "host_operation": "a.set", "target": "x", "magnitude": 0.1},
            {"host_id": "B", "host_operation": "b.set", "target": "y", "magnitude": 0.2},
        ], "DECLARED_ATOMIC_SIMULATION", 1.0)
        result = coord.commit("m1", 2.0)
        self.assertEqual(result["state"], "COMMITTED")

    def test_best_effort_failure_compensates_prior_hosts(self):
        a = MockHostEndpoint("A", rollback_bindings={"a.set": "a.undo"})
        b = MockHostEndpoint("B", rollback_bindings={"b.set": "b.undo"}, fail_operations=["b.set"])
        coord = MultiHostCommitCoordinator({"A": a, "B": b})
        coord.prepare("m1", [
            {"host_id": "A", "host_operation": "a.set", "target": "x", "magnitude": 0.1},
            {"host_id": "B", "host_operation": "b.set", "target": "y", "magnitude": 0.2},
        ], "BEST_EFFORT", 1.0)
        result = coord.commit("m1", 2.0)
        self.assertEqual(result["state"], "ABORTED_COMPENSATED")
        execution = next(iter(a.executions.values()))
        self.assertEqual(execution["state"], "ROLLED_BACK")

    def test_compensation_failure_requires_manual_reconciliation(self):
        a = MockHostEndpoint("A", rollback_bindings={"a.set": "a.undo"}, rollback_fail_operations=["a.set"])
        b = MockHostEndpoint("B", rollback_bindings={"b.set": "b.undo"}, fail_operations=["b.set"])
        coord = MultiHostCommitCoordinator({"A": a, "B": b})
        coord.prepare("m1", [
            {"host_id": "A", "host_operation": "a.set", "target": "x", "magnitude": 0.1},
            {"host_id": "B", "host_operation": "b.set", "target": "y", "magnitude": 0.2},
        ], "BEST_EFFORT", 1.0)
        result = coord.commit("m1", 2.0)
        self.assertEqual(result["state"], "MANUAL_RECONCILIATION_REQUIRED")

    def test_irreversible_boundary_requires_explicit_last_position(self):
        a = MockHostEndpoint("A", rollback_bindings={"a.set": "a.undo"})
        b = MockHostEndpoint("B")
        coord = MultiHostCommitCoordinator({"A": a, "B": b})
        commands = [
            {"host_id": "B", "host_operation": "b.fire", "target": "y", "magnitude": 1.0},
            {"host_id": "A", "host_operation": "a.set", "target": "x", "magnitude": 0.1},
        ]
        bad = coord.prepare("m1", commands, "BEST_EFFORT", 1.0, allow_irreversible_boundary=True)
        self.assertEqual(bad["reason"], "IRREVERSIBLE_BOUNDARY_VIOLATION")
        coord2 = MultiHostCommitCoordinator({"A": a, "B": b})
        good = coord2.prepare("m2", list(reversed(commands)), "BEST_EFFORT", 1.0, allow_irreversible_boundary=True)
        self.assertEqual(good["state"], "PREPARED")
        self.assertEqual(coord2.commit("m2", 2.0)["state"], "COMMITTED")

    def test_multi_host_journal_records_boundary_events(self):
        journal = AppendOnlyJournal(self.root / "multi.jsonl")
        a = MockHostEndpoint("A", rollback_bindings={"a.set": "a.undo"})
        coord = MultiHostCommitCoordinator({"A": a}, journal=journal)
        coord.prepare("m1", [{"host_id": "A", "host_operation": "a.set", "target": "x", "magnitude": 0.1}], "BEST_EFFORT", 1.0)
        coord.commit("m1", 2.0)
        self.assertTrue(journal.verify())
        self.assertEqual([x["event_type"] for x in journal.records], ["MULTI_HOST_PREPARED", "MULTI_HOST_COMMITTED"])


if __name__ == "__main__":
    unittest.main()
