# GCF-UMA v0.1c Result Memo

Verdict: `DURABLE_JOURNAL_CRASH_RECOVERY_MULTI_HOST_BOUNDARIES_PASS`

Milestone: `FORMAL_SYNTHETIC_ADAPTER_CORE_COMPLETE_CANDIDATE`

## Formal results

- v0.1c durable/multi-host gates: **16/16 PASS**
- total unit/regression tests: **62/62 PASS**
- v0.1 adapter regression: 10/10 PASS
- v0.1a multiplex regression: 20/20 PASS
- v0.1b transactional regression: 16/16 PASS
- v0.1c durability/multi-host tests: 16/16 PASS

## Durable journal result

The local JSONL journal provides:

- monotonic sequence numbers;
- SHA256 previous-record hash chaining;
- `flush + fsync` on append;
- restart loading and chain verification;
- safe truncation of an incomplete final record;
- hard failure on interior corruption, sequence discontinuity, or hash mismatch.

The journal is a local tamper-evident recovery artifact. It is not a replicated log, signature, consensus mechanism, or non-repudiation system.

## Crash recovery result

Validated restart cases include:

1. **Prepared, not executed:** restored as `PREPARED`, with zero host executions.
2. **Committed before restart:** repeated commit remains idempotent and does not re-execute.
3. **Host executed, coordinator commit snapshot absent:** persistent host receipt is matched through the deterministic idempotency key and reconciled to `COMMITTED` without duplicate execution.
4. **Only part of the expected host receipts present:** transaction enters `HOST_RECONCILIATION_REQUIRED`.
5. **Pending deadline expired during downtime:** recovered transaction becomes `TIMED_OUT` with zero execution.
6. **Session/replay state:** active/retired sessions, last sequence, and seen-message IDs survive restart.

## Multi-host boundary result

Two semantics are now explicit:

### Best effort

Sequential execution with reverse-order compensation for operations declared reversible. A later-host failure produced successful compensation in the locked test. Injected compensation failure correctly produced `MANUAL_RECONCILIATION_REQUIRED`.

### Declared atomic simulation

A plan is rejected unless every mock host declares atomic capability. Passing this gate means only that the capability declaration and local mock boundary are enforced. It does not establish real atomicity.

## Irreversible boundary

Best-effort plans reject irreversible commands unless exactly one is present, the caller opts in explicitly, and the command is last. This reduces the possibility of a later failure after an irreversible action; it does not certify the action itself.

## Completion-candidate rationale

The originally planned generic Adapter method-core layers are now present and regression-preserved:

- reusable contract and host binding;
- branch multiplexing and role separation;
- transaction and replay discipline;
- failure recovery and supplementary evidence;
- local durability and restart reconstruction;
- multi-host semantics, compensation, and irreversible boundaries.

Further work should move to thin domain/host profiles or real integration harnesses rather than adding more generic responsibilities to UMA.

## Boundary

This result remains a deterministic locked synthetic/mock result. It does not establish production filesystem guarantees, concurrent writer correctness, database durability, distributed atomic commit, real host crash semantics, network partitions, cryptographic branch identity, independent certificate truth, Safety Governor authorization, or energy/fusion/6G deployment safety.
