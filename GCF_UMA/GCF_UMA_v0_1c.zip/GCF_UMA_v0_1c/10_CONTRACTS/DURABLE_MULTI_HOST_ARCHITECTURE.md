# Durable Journal, Crash Recovery, and Multi-Host Boundaries

## Purpose

v0.1c closes the last method-core gap left by v0.1b: process memory is no longer the sole record of session, replay, transaction, adapter-ramp, and host-execution state.

## Local durable path

```text
branch envelopes
  → v0.1b validation / prepare
  → coordinator snapshot journal
  → host execution journal
  → coordinator commit snapshot
```

The coordinator and host journals are intentionally separate. A crash may therefore occur after the host receipt is durable but before the coordinator records `COMMITTED`. Recovery must inspect deterministic idempotency keys and reconcile the host receipt instead of executing the command again.

## Recovery cases

### Prepared, no host receipt

The transaction remains prepared after restart. No execution is inferred.

### All expected host receipts present

The coordinator reconstructs the committed state, restores Adapter ramp state from the bound magnitudes, and emits a reconciliation receipt.

### Only some expected receipts present

The transaction enters `HOST_RECONCILIATION_REQUIRED`. Automatic completion or rollback is prohibited because the observed host state is incomplete.

### Incomplete final journal record

Only an invalid final JSON fragment may be removed. Any sequence, hash, or interior-record corruption is a hard failure.

## Multi-host modes

### `BEST_EFFORT`

Commands execute sequentially. If a later command fails, earlier reversible commands are compensated in reverse order. Compensation failure produces `MANUAL_RECONCILIATION_REQUIRED`.

### `DECLARED_ATOMIC_SIMULATION`

This mode is accepted only when every mock endpoint declares atomic capability. The label is deliberately explicit: it is a local capability-boundary simulation, not distributed atomic commit, two-phase commit, or consensus.

## Irreversible-operation boundary

A best-effort plan may include one irreversible command only when:

1. the caller opts in explicitly;
2. it is the final command;
3. all preceding commands are reversible.

This ordering prevents a later failure from occurring after an irreversible side effect. It does not make the irreversible command safe or reversible.
