# GCF-UMA Branch Charter — v0.1c

## Core responsibility

GCF-UMA is reusable integration middleware between GCF branch contracts, generic domain contracts, domain/host profiles, transactional host binding, and explicit local durability / multi-host boundaries.

## Locked branch roles

- OBS-CoreV2: evidence, observation requests, and bounded-policy advisories.
- AI-8: the only registered final action-intent provider in the current multiplex profile.
- BH: topology/margin annotation only.
- BCRC-PGRC: explicit certificate status only.
- GCF-UMA: contract validation, routing, provenance preservation, ambiguity blocking, transaction staging, local durable recovery, and host binding.

## v0.1c durable rule

A recovered transaction must be reconstructed only from verified journal records and persistent host receipts.

- Prepared state without a host receipt remains prepared.
- A complete matching host-receipt set may close the commit crash window without re-execution.
- A partial host-receipt set requires manual reconciliation.
- A truncated final journal fragment may be removed; interior corruption is fatal.

## Multi-host rule

- `BEST_EFFORT` means sequential execution plus declared compensation where possible.
- `DECLARED_ATOMIC_SIMULATION` is a local mock boundary accepted only when every endpoint declares atomic capability.
- Neither mode may be described as real distributed atomic commit.
- An irreversible best-effort command requires explicit opt-in and must be last.

## Non-responsibilities

- no OBS structural-risk inference;
- no AI-8 route calculation;
- no BH margin calculation;
- no BCRC-PGRC certificate generation or independent truth validation;
- no Safety Governor authorization;
- no distributed consensus, production two-phase commit, or durable database guarantee;
- no cryptographic identity or hostile-network security guarantee;
- no domain optimization or real-device safety certification.
